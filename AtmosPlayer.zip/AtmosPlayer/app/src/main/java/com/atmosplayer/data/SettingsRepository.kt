package com.atmosplayer.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("atmos_settings")

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext ctx: Context) {
    private val ds = ctx.dataStore

    companion object {
        val KEY_DARK = booleanPreferencesKey("dark_mode")
        val KEY_ANIMATED_ARTWORK = booleanPreferencesKey("animated_artwork")
        val KEY_GLASS_EFFECT = booleanPreferencesKey("glass_effect")
        val KEY_SHOW_TRANSLATION = booleanPreferencesKey("show_translation")
        val KEY_CROSSFADE_MS = intPreferencesKey("crossfade_ms")
        // 扫描范围（参考 OuterTune Local Media：白/黑名单互斥，黑名单可在白名单内排除子目录）
        val KEY_SCAN_MODE = intPreferencesKey("scan_mode")          // 0=全盘 1=白名单 2=黑名单
        val KEY_SCAN_WHITELIST = stringSetPreferencesKey("scan_whitelist")
        val KEY_SCAN_BLACKLIST = stringSetPreferencesKey("scan_blacklist")
        // 播放页默认沉浸封面模式
        val KEY_IMMERSIVE_COVER = booleanPreferencesKey("immersive_cover")

        /** 白名单默认预选：用户主音乐目录 */
        val DEFAULT_WHITELIST = setOf("/storage/emulated/0/DolbyAt")
    }

    val darkMode: Flow<Boolean> = ds.data.map { it[KEY_DARK] ?: true }
    val animatedArtwork: Flow<Boolean> = ds.data.map { it[KEY_ANIMATED_ARTWORK] ?: true }
    val glassEffect: Flow<Boolean> = ds.data.map { it[KEY_GLASS_EFFECT] ?: true }
    val showTranslation: Flow<Boolean> = ds.data.map { it[KEY_SHOW_TRANSLATION] ?: true }
    val immersiveCover: Flow<Boolean> = ds.data.map { it[KEY_IMMERSIVE_COVER] ?: false }

    val scanMode: Flow<Int> = ds.data.map { it[KEY_SCAN_MODE] ?: 0 }
    val scanWhitelist: Flow<Set<String>> = ds.data.map { it[KEY_SCAN_WHITELIST] ?: DEFAULT_WHITELIST }
    val scanBlacklist: Flow<Set<String>> = ds.data.map { it[KEY_SCAN_BLACKLIST] ?: emptySet() }

    suspend fun setDarkMode(v: Boolean) = ds.edit { it[KEY_DARK] = v }
    suspend fun setAnimatedArtwork(v: Boolean) = ds.edit { it[KEY_ANIMATED_ARTWORK] = v }
    suspend fun setGlassEffect(v: Boolean) = ds.edit { it[KEY_GLASS_EFFECT] = v }
    suspend fun setShowTranslation(v: Boolean) = ds.edit { it[KEY_SHOW_TRANSLATION] = v }
    suspend fun setImmersiveCover(v: Boolean) = ds.edit { it[KEY_IMMERSIVE_COVER] = v }

    suspend fun setScanMode(v: Int) = ds.edit { it[KEY_SCAN_MODE] = v }
    suspend fun addWhitelist(path: String) = ds.edit {
        it[KEY_SCAN_WHITELIST] = (it[KEY_SCAN_WHITELIST] ?: DEFAULT_WHITELIST) + path
    }
    suspend fun removeWhitelist(path: String) = ds.edit {
        it[KEY_SCAN_WHITELIST] = (it[KEY_SCAN_WHITELIST] ?: DEFAULT_WHITELIST) - path
    }
    suspend fun setWhitelist(paths: Set<String>) = ds.edit { it[KEY_SCAN_WHITELIST] = paths }
    suspend fun addBlacklist(path: String) = ds.edit {
        it[KEY_SCAN_BLACKLIST] = (it[KEY_SCAN_BLACKLIST] ?: emptySet()) + path
    }
    suspend fun removeBlacklist(path: String) = ds.edit {
        it[KEY_SCAN_BLACKLIST] = (it[KEY_SCAN_BLACKLIST] ?: emptySet()) - path
    }
}
