package com.atmosplayer.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.atmosplayer.data.SettingsRepository
import com.atmosplayer.data.db.TrackDao
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.lyrics.LyricSource
import com.atmosplayer.lyrics.Lyrics
import com.atmosplayer.lyrics.LyricsRepository
import com.atmosplayer.playback.DolbyCapabilities
import com.atmosplayer.playback.PlayerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@UnstableApi
@HiltViewModel
class PlayerViewModel @Inject constructor(
    val playerManager: PlayerManager,
    private val lyricsRepo: LyricsRepository,
    private val trackDao: TrackDao,
    private val settings: SettingsRepository
) : ViewModel() {

    val player = playerManager.state

    private val _lyrics = MutableStateFlow(Lyrics(emptyList(), LyricSource.NONE, false))
    val lyrics: StateFlow<Lyrics> = _lyrics.asStateFlow()

    private val _currentTrack = MutableStateFlow<TrackEntity?>(null)
    val currentTrack = _currentTrack.asStateFlow()

    private val _lyricOffset = MutableStateFlow(0L)
    val lyricOffset = _lyricOffset.asStateFlow()

    val showTranslation = settings.showTranslation
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val animatedArtworkEnabled = settings.animatedArtwork
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val immersiveCoverDefault = settings.immersiveCover
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun setImmersiveCoverDefault(v: Boolean) {
        viewModelScope.launch { settings.setImmersiveCover(v) }
    }

    /** 手动重新检测杜比能力 */
    fun redetectDolby() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val r = runCatching { DolbyCapabilities.detect() }.getOrNull()
            dolbyReport.value = r
            if (r != null) DolbyCapabilities.logReport(r)
        }
    }

    val dolbyReport = MutableStateFlow<DolbyCapabilities.Report?>(null)

    private var lyricJob: Job? = null
    private var lastTrackId: String? = null

    init {
        // 启动自动检测杜比能力：MediaCodecList 遍历可能耗时，放到 IO 线程避免主线程卡顿/ANR
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val r = runCatching { DolbyCapabilities.detect() }.getOrNull()
            dolbyReport.value = r
            if (r != null) DolbyCapabilities.logReport(r)
        }
        viewModelScope.launch {
            playerManager.state.collect { s ->
                val id = s.currentTrackId
                if (id != null && id != lastTrackId) {
                    lastTrackId = id
                    val track = trackDao.byId(id)
                    _currentTrack.value = track
                    _lyricOffset.value = lyricsRepo.offset(id)
                    lyricJob?.cancel()
                    lyricJob = launch {
                        _lyrics.value = runCatching {
                            if (track != null) lyricsRepo.load(track)
                            else Lyrics(emptyList(), LyricSource.NONE, false)
                        }.getOrElse {
                            android.util.Log.e("AtmosPlayer", "lyrics load failed", it)
                            Lyrics(emptyList(), LyricSource.NONE, false)
                        }
                    }
                }
            }
        }
    }

    fun adjustOffset(deltaMs: Long) {
        val id = lastTrackId ?: return
        val newV = _lyricOffset.value + deltaMs
        _lyricOffset.value = newV
        viewModelScope.launch { lyricsRepo.saveOffset(id, newV) }
    }

    fun seekToLine(startMs: Long) = playerManager.seekTo(startMs - _lyricOffset.value)
}
