package com.atmosplayer.playback

import android.media.AudioFormat
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

/**
 * MediaInfo 风格歌曲详情：通用 / 标签 / 音频流 / 其他 四组字段。
 * 数据源：MediaExtractor + MediaFormat + MediaMetadataRetriever + 文件头嗅探（WAV fmt / FLAC STREAMINFO / ID3）。
 * 所有字段优雅降级：拿不到就是 null，UI 显示 "-"，绝不抛异常。
 */
object TrackDetailLoader {

    data class Details(
        // 通用
        val fileName: String? = null,
        val filePath: String? = null,
        val container: String? = null,
        val fileSizeBytes: Long = 0,
        val durationMs: Long = 0,
        val overallBitrate: Int = 0,
        // 标签
        val title: String? = null,
        val artist: String? = null,
        val album: String? = null,
        val albumArtist: String? = null,
        val genre: String? = null,
        val year: String? = null,
        val copyright: String? = null,
        val encodedDate: String? = null,
        val tagType: String? = null,
        // 音频流
        val codec: String? = null,
        val codecId: String? = null,
        val mime: String? = null,
        val bitrate: Int = 0,
        val bitrateMode: String? = null,       // CBR / VBR
        val sampleRate: Int = 0,
        val channelCount: Int = 0,
        val channelLayout: String? = null,
        val bitDepth: Int = 0,
        val compressionMode: String? = null,   // 有损 / 无损
        val streamSizeBytes: Long = 0,
        val samplingCount: Long = 0,
        val decoderName: String? = null,
        val isDolbyAtmos: Boolean = false,
        val isDolby: Boolean = false,
        val isHiRes: Boolean = false,
        // 其他
        val artworkSource: String? = null,
        val lyricsSource: String? = null,
        val trackCount: Int = 0,
        val encoder: String? = null
    )

    suspend fun load(path: String, liveInfo: FormatInspector.AudioInfo? = null): Details =
        withContext(Dispatchers.IO) {
            val file = File(path)
            val fileSize = runCatching { file.length() }.getOrDefault(0L)
            var d = Details(
                fileName = file.name,
                filePath = path,
                fileSizeBytes = fileSize,
                container = containerName(path)
            )

            // ---- MediaExtractor / MediaFormat（WAV setDataSource 失败也有 FD 兜底）----
            runCatching {
                val ext = MediaExtractor()
                try {
                    runCatching { ext.setDataSource(path) }.onFailure {
                        ext.setDataSource(java.io.FileInputStream(path).fd)
                    }
                    d = d.copy(trackCount = ext.trackCount)
                    for (i in 0 until ext.trackCount) {
                        val f = ext.getTrackFormat(i)
                        val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                        if (!mime.startsWith("audio/")) continue
                        d = d.copy(
                            mime = mime,
                            codecId = f.getString(MediaFormat.KEY_CODECS_STRING),
                            bitrate = f.intOrNull(MediaFormat.KEY_BIT_RATE) ?: 0,
                            sampleRate = f.intOrNull(MediaFormat.KEY_SAMPLE_RATE) ?: 0,
                            channelCount = f.intOrNull(MediaFormat.KEY_CHANNEL_COUNT) ?: 0,
                            durationMs = (f.longOrNull(MediaFormat.KEY_DURATION) ?: 0L) / 1000,
                            bitrateMode = if (Build.VERSION.SDK_INT >= 31)
                                when (f.intOrNull(MediaFormat.KEY_BITRATE_MODE)) {
                                    2 -> "CBR"   // MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                                    1 -> "VBR"   // BITRATE_MODE_VBR
                                    0 -> "CQ"
                                    else -> null
                                } else null,
                            bitDepth = when (f.intOrNull(MediaFormat.KEY_PCM_ENCODING)) {
                                AudioFormat.ENCODING_PCM_8BIT -> 8
                                AudioFormat.ENCODING_PCM_16BIT -> 16
                                AudioFormat.ENCODING_PCM_24BIT_PACKED, AudioFormat.ENCODING_PCM_32BIT -> 24
                                AudioFormat.ENCODING_PCM_FLOAT -> 32
                                else -> 0
                            }
                        )
                        break
                    }
                } finally {
                    runCatching { ext.release() }
                }
            }.onFailure {
                com.atmosplayer.util.Trace.log("detail[$path] extractor failed: ${it.message}")
            }

            // ---- MediaMetadataRetriever 标签 ----
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(path)
                fun meta(key: Int) = runCatching { mmr.extractMetadata(key) }.getOrNull()
                    ?.takeIf { it.isNotBlank() }
                d = d.copy(
                    title = meta(MediaMetadataRetriever.METADATA_KEY_TITLE),
                    artist = meta(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                    album = meta(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                    albumArtist = meta(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                    genre = meta(MediaMetadataRetriever.METADATA_KEY_GENRE),
                    year = meta(MediaMetadataRetriever.METADATA_KEY_YEAR),
                    encodedDate = meta(MediaMetadataRetriever.METADATA_KEY_DATE),
                    durationMs = if (d.durationMs > 0) d.durationMs
                        else meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0,
                    bitrate = if (d.bitrate > 0) d.bitrate
                        else meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
                )
            } catch (e: Throwable) {
                com.atmosplayer.util.Trace.log("detail[$path] retriever failed: ${e.message}")
            } finally {
                runCatching { mmr.release() }
            }

            // ---- m4a 直读原子：补 编码器/版权/专辑艺术家/年份 ----
            if (path.endsWith(".m4a", true) || path.endsWith(".mp4", true)) {
                val tags = runCatching { com.atmosplayer.lyrics.Mp4AtomReader.read(path) }.getOrNull()
                if (tags != null) {
                    d = d.copy(
                        title = d.title ?: tags.title,
                        artist = d.artist ?: tags.artist,
                        album = d.album ?: tags.album,
                        albumArtist = d.albumArtist ?: tags.albumArtist,
                        genre = d.genre ?: tags.genre,
                        year = d.year ?: tags.year,
                        copyright = tags.copyright,
                        encoder = tags.encoder
                    )
                }
            }

            // ---- 文件头嗅探：位深 + 标签类型 ----
            val sniff = sniffHeader(path)
            if (d.bitDepth == 0) d = d.copy(bitDepth = sniff.first)
            d = d.copy(tagType = sniff.second)

            // ---- 播放中的实时格式信息优先 ----
            if (liveInfo != null) {
                d = d.copy(
                    bitrate = if (liveInfo.bitrate > 0) liveInfo.bitrate else d.bitrate,
                    sampleRate = if (liveInfo.sampleRate > 0) liveInfo.sampleRate else d.sampleRate,
                    channelCount = if (liveInfo.channelCount > 0) liveInfo.channelCount else d.channelCount,
                    codec = liveInfo.codec.takeIf { it != "-" } ?: d.codec,
                    mime = liveInfo.mime.takeIf { it != "-" } ?: d.mime,
                    isDolbyAtmos = liveInfo.isDolbyAtmos,
                    isDolby = liveInfo.isDolby,
                    channelLayout = liveInfo.channelLayout.takeIf { it != "-" }
                )
            }
            if (d.codec == null) d = d.copy(codec = codecName(d.mime, path))
            if (d.codecId == null) d = d.copy(codecId = d.codec)

            val durationSec = d.durationMs / 1000.0
            d = d.copy(
                overallBitrate = if (durationSec > 0 && fileSize > 0)
                    (fileSize * 8 / durationSec).toInt() else d.bitrate,
                isDolbyAtmos = d.isDolbyAtmos || DolbyCapabilities.isAtmosMime(d.mime) ||
                        DolbyCapabilities.isAtmosMime(d.codec),
                isDolby = d.isDolby || DolbyCapabilities.isDolbyMime(d.mime),
                decoderName = DolbyCapabilities.decoderNameFor(d.mime ?: d.codec),
                compressionMode = if (isLossless(d.mime, path)) "无损 (Lossless)" else "有损 (Lossy)",
                streamSizeBytes = if (d.bitrate > 0 && durationSec > 0)
                    (d.bitrate / 8.0 * durationSec).toLong() else 0,
                samplingCount = if (d.sampleRate > 0 && durationSec > 0)
                    (d.sampleRate * durationSec).toLong() else 0,
                channelLayout = d.channelLayout ?: channelLayoutName(d.channelCount)
            )
            d = d.copy(isHiRes = isLossless(d.mime, path) &&
                    (d.sampleRate > 48000 || d.bitDepth > 16))

            // ---- 其他：封面/歌词来源 ----
            val art = com.atmosplayer.artwork.ArtworkBytes.peekSource(path)
            d = d.copy(artworkSource = art)

            d
        }

    // ---------------- 工具 ----------------

    private fun MediaFormat.intOrNull(key: String): Int? =
        runCatching { if (containsKey(key)) getInteger(key) else null }.getOrNull()

    private fun MediaFormat.longOrNull(key: String): Long? =
        runCatching { if (containsKey(key)) getLong(key) else null }.getOrNull()

    private fun containerName(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "m4a", "mp4" -> "MPEG-4 (Apple iTunes AAC/ALAC)"
        "flac" -> "FLAC (Free Lossless Audio Codec)"
        "mp3" -> "MPEG Audio (MP3)"
        "wav" -> "WAVE (RIFF)"
        "ogg" -> "Ogg (Vorbis/Opus)"
        "opus" -> "Ogg Opus"
        "aac" -> "ADTS AAC"
        "aiff", "aif" -> "AIFF"
        "ape" -> "Monkey's Audio"
        "dsf", "dff" -> "DSD"
        else -> "未知容器"
    }

    private fun codecName(mime: String?, path: String): String? {
        mime ?: return path.substringAfterLast('.', "").uppercase().ifBlank { null }
        return when {
            mime.contains("ac4") -> "AC-4 (Dolby Atmos)"
            mime.contains("eac3-joc") -> "E-AC-3 JOC (Dolby Atmos)"
            mime.contains("eac3") -> "E-AC-3 (Dolby Digital Plus)"
            mime == "audio/ac3" -> "AC-3 (Dolby Digital)"
            mime.contains("mp4a") || mime.contains("aac") -> "AAC"
            mime.contains("alac") -> "ALAC (Apple Lossless)"
            mime.contains("flac") -> "FLAC"
            mime.contains("mpeg") -> "MP3"
            mime.contains("raw") || mime.contains("wav") -> "PCM"
            mime.contains("opus") -> "Opus"
            mime.contains("vorbis") -> "Vorbis"
            else -> mime
        }
    }

    private fun isLossless(mime: String?, path: String): Boolean {
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext in setOf("flac", "alac", "wav", "aiff", "aif", "ape", "dsf", "dff")) return true
        val m = mime?.lowercase() ?: return false
        return m.contains("flac") || m.contains("alac") || m.contains("raw") || m.contains("wav")
    }

    private fun channelLayoutName(channels: Int): String? = when (channels) {
        1 -> "Mono (1/0)"
        2 -> "Stereo (2/0, L R)"
        6 -> "5.1 (3/2/0.1, L R C LFE Ls Rs)"
        8 -> "7.1 (3/2/2.1, L R C LFE Ls Rs Lrs Rrs)"
        0 -> null
        else -> "${channels}ch"
    }

    /** 嗅探文件头：返回 (位深, 标签类型)。WAV fmt chunk / FLAC STREAMINFO / ID3v2 版本 */
    private fun sniffHeader(path: String): Pair<Int, String?> = runCatching {
        RandomAccessFile(path, "r").use { f ->
            val head = ByteArray(12)
            f.readFully(head)
            val s = String(head, 0, 4, Charsets.ISO_8859_1)
            when {
                head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte() ->
                    0 to "ID3v2.${head[3].toInt()}"
                s == "fLaC" -> {
                    // STREAMINFO 块：跳过 4 字节块头，位深在 byte 10 的低5bit + byte11 高1bit
                    f.seek(8 + 4)
                    val si = ByteArray(34)
                    f.readFully(si)
                    val bps = ((si[10].toInt() and 0x01) shl 4) or ((si[11].toInt() and 0xF0) ushr 4)
                    (bps + 1) to "Vorbis Comment"
                }
                s == "RIFF" -> {
                    // 遍历 chunk 找 fmt 的 bitsPerSample（偏移 34 附近，遍历稳妥）
                    var bits = 0
                    var foundInfo = false
                    var pos = 12L
                    while (pos + 8 <= f.length() && pos < 4096) {
                        f.seek(pos)
                        val id = ByteArray(4); f.readFully(id)
                        val size = Integer.reverseBytes(f.readInt()).toLong() and 0xFFFFFFFF
                        val name = String(id, Charsets.ISO_8859_1)
                        if (name == "fmt " && size >= 16) {
                            f.seek(pos + 8 + 14)
                            bits = java.lang.Short.reverseBytes(f.readShort()).toInt() and 0xFFFF
                        }
                        if (name == "LIST") foundInfo = true
                        pos += 8 + size + (size and 1)
                    }
                    bits to if (foundInfo) "RIFF LIST-INFO" else "无标签 (PCM 裸文件)"
                }
                else -> 0 to null
            }
        }
    }.getOrDefault(0 to null)

    fun fmtSize(bytes: Long): String = when {
        bytes <= 0 -> "-"
        bytes >= 1 shl 20 -> "%.1f MB".format(bytes / 1048576f)
        else -> "%.0f KB".format(bytes / 1024f)
    }

    fun fmtBitrate(bps: Int): String = if (bps > 0) "%.0f kb/s".format(bps / 1000f) else "-"
}
