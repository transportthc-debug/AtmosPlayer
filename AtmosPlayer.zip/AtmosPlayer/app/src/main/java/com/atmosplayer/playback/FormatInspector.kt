package com.atmosplayer.playback

import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi

/** 从当前播放轨道提取格式信息，生成"音频信息面板"数据。 */
@UnstableApi
object FormatInspector {

    data class AudioInfo(
        val mime: String = "-",
        val codec: String = "-",
        val bitrate: Int = 0,
        val sampleRate: Int = 0,
        val channelCount: Int = 0,
        val channelLayout: String = "-",
        val isDolbyAtmos: Boolean = false,
        val isDolby: Boolean = false,
        val decoderName: String = "-"
    )

    fun fromPlayer(player: Player): AudioInfo {
        val tracks: Tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type != androidx.media3.common.C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSelected(i)) continue
                val f: Format = group.getTrackFormat(i)
                val mime = f.sampleMimeType ?: "-"
                return AudioInfo(
                    mime = mime,
                    codec = f.codecs ?: mime,
                    bitrate = f.bitrate,
                    sampleRate = f.sampleRate,
                    channelCount = f.channelCount,
                    channelLayout = channelLayoutName(mime, f.channelCount),
                    isDolbyAtmos = DolbyCapabilities.isAtmosMime(mime),
                    isDolby = DolbyCapabilities.isDolbyMime(mime),
                    decoderName = mime
                )
            }
        }
        return AudioInfo()
    }

    private fun channelLayoutName(mime: String, channels: Int): String = when {
        DolbyCapabilities.isAtmosMime(mime) && channels <= 2 -> "Immersive Stereo (Atmos 对象音频)"
        DolbyCapabilities.isAtmosMime(mime) -> "Immersive ${channels}ch (Atmos 对象音频)"
        channels == 1 -> "Mono"
        channels == 2 -> "Stereo"
        channels == 6 -> "5.1"
        channels == 8 -> "7.1"
        channels > 0 -> "${channels}ch"
        else -> "-"
    }
}
