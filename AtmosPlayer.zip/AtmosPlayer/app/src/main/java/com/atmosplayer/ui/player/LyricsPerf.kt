package com.atmosplayer.ui.player

import com.atmosplayer.util.Trace
import java.util.concurrent.atomic.AtomicLong

/**
 * 歌词渲染性能埋点：tick 频率、行/词索引更新、重组计数、滚动动画、手动打断、jank 粗统计。
 * 每 10s 汇总写入 trace.txt 一行；全部原子计数，主线程安全无锁。
 */
object LyricsPerf {
    private val ticks = AtomicLong(0)              // position tick 次数
    private val lineIndexUpdates = AtomicLong(0)   // currentLineIndex 变化次数
    private val wordIndexUpdates = AtomicLong(0)   // 当前词索引变化次数
    private val currentLineRecompositions = AtomicLong(0) // 当前行重组次数（近似）
    private val autoScrolls = AtomicLong(0)        // 自动滚动触发次数
    private val manualInterrupts = AtomicLong(0)   // 手动滑动打断次数
    private val scrollAnimTotalMs = AtomicLong(0)  // 滚动动画总耗时
    private val jankFrames = AtomicLong(0)         // >34ms 的帧数
    private val totalFrames = AtomicLong(0)

    fun tick() { ticks.incrementAndGet() }
    fun lineIndexChanged() { lineIndexUpdates.incrementAndGet() }
    fun wordIndexChanged() { wordIndexUpdates.incrementAndGet() }
    fun currentLineRecomposed() { currentLineRecompositions.incrementAndGet() }
    fun autoScroll(durationMs: Long) { autoScrolls.incrementAndGet(); scrollAnimTotalMs.addAndGet(durationMs) }
    fun manualInterrupt() { manualInterrupts.incrementAndGet() }
    fun frame(deltaMs: Long) {
        totalFrames.incrementAndGet()
        if (deltaMs > 34) jankFrames.incrementAndGet()
    }

    fun reset() {
        ticks.set(0); lineIndexUpdates.set(0); wordIndexUpdates.set(0)
        currentLineRecompositions.set(0); autoScrolls.set(0); manualInterrupts.set(0)
        scrollAnimTotalMs.set(0); jankFrames.set(0); totalFrames.set(0)
    }

    /** 汇总一行日志并清零。windowSec = 统计窗口秒数。任何异常都不允许影响歌词页 */
    fun flush(windowSec: Int) = runCatching {
        val t = ticks.get()
        val f = totalFrames.get()
        val avgScroll = if (autoScrolls.get() > 0) scrollAnimTotalMs.get() / autoScrolls.get() else 0
        val jankPct = if (f > 0) jankFrames.get() * 100 / f else 0
        // 用 Kotlin 字符串模板，彻底避免 String.format 占位符类型错位崩溃
        Trace.log(
            "lyrics.perf: tick=${"%.1f".format(t.toFloat() / windowSec)}Hz " +
            "lineIdxUpdates=${lineIndexUpdates.get()} wordIdxUpdates=${wordIndexUpdates.get()} " +
            "lineRecompose=${currentLineRecompositions.get()} " +
            "autoScroll=${autoScrolls.get()}(avg ${avgScroll}ms) " +
            "manualInterrupt=${manualInterrupts.get()} " +
            "frames=$f jank=${jankFrames.get()}($jankPct%)"
        )
        reset()
    }
}
