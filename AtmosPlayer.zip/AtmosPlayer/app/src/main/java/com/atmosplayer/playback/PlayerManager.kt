package com.atmosplayer.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.atmosplayer.data.db.PlaybackStateDao
import com.atmosplayer.data.db.PlaybackStateEntity
import com.atmosplayer.data.db.TrackDao
import com.atmosplayer.data.db.TrackEntity
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/** UI 与 PlaybackService 之间的唯一桥梁（MediaController）。 */
@UnstableApi
@Singleton
class PlayerManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val trackDao: TrackDao,
    private val stateDao: PlaybackStateDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    data class UiState(
        val connected: Boolean = false,
        val isPlaying: Boolean = false,
        val currentTrackId: String? = null,
        val title: String = "",
        val artist: String = "",
        val album: String = "",
        val artworkKey: String? = null,   // "art://<path>"，供 Coil 提取内嵌封面
        val positionMs: Long = 0,
        val durationMs: Long = 0,
        val audioInfo: FormatInspector.AudioInfo = FormatInspector.AudioInfo(),
        val shuffle: Boolean = false,
        val repeatMode: Int = Player.REPEAT_MODE_OFF,
        val queueTitles: List<Pair<String, String>> = emptyList()
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    var controller: MediaController? = null
        private set

    fun connect() {
        if (controller != null) return
        com.atmosplayer.util.Trace.log("connect.begin")
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            val c = try { future.get() } catch (e: Exception) {
                com.atmosplayer.util.Trace.error("controller.connect", e)
                return@addListener
            }
            try {
                controller = c
                c.addListener(listener)
                _state.value = _state.value.copy(connected = true)
                com.atmosplayer.util.Trace.log("controller.connected")
                startPositionTicker()
                restoreState()
                refresh()
                com.atmosplayer.util.Trace.log("connect.done")
            } catch (e: Throwable) {
                com.atmosplayer.util.Trace.error("connect.post", e)
            }
        }, MoreExecutors.directExecutor())
    }

    fun playQueue(tracks: List<TrackEntity>, startIndex: Int) {
        com.atmosplayer.util.Trace.log("playQueue size=${tracks.size} index=$startIndex")
        val c = controller ?: run {
            com.atmosplayer.util.Trace.log("playQueue ABORT: controller null")
            return
        }
        if (tracks.isEmpty() || startIndex !in tracks.indices) {
            com.atmosplayer.util.Trace.log("playQueue ABORT: empty/bad index")
            return
        }
        try {
            c.setMediaItems(tracks.map { it.toMediaItem() }, startIndex, 0L)
            com.atmosplayer.util.Trace.log("playQueue.setMediaItems.ok")
            c.prepare()
            com.atmosplayer.util.Trace.log("playQueue.prepare.ok")
            c.play()
            com.atmosplayer.util.Trace.log("playQueue.play.ok")
        } catch (e: Throwable) {
            com.atmosplayer.util.Trace.error("playQueue", e)
            return
        }
        scope.launch { tracks.getOrNull(startIndex)?.let { trackDao.markPlayed(it.id, System.currentTimeMillis()) } }
        persistQueue(tracks, startIndex, 0L)
    }

    fun togglePlay() = controller?.let { if (it.isPlaying) it.pause() else it.play() }
    fun next() = controller?.seekToNextMediaItem()
    fun prev() = controller?.seekToPreviousMediaItem()
    fun seekTo(ms: Long) = controller?.seekTo(ms)
    fun seekToIndex(i: Int) = controller?.seekTo(i, 0)
    fun toggleShuffle() = controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = controller?.let {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun moveQueueItem(from: Int, to: Int) = controller?.moveMediaItem(from, to)
    fun removeQueueItem(i: Int) = controller?.removeMediaItem(i)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { refresh() }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            refresh()
            scope.launch {
                mediaItem?.mediaId?.let { trackDao.markPlayed(it, System.currentTimeMillis()) }
                persistCurrent()
            }
        }
        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) { refresh() }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { refresh() }
        override fun onRepeatModeChanged(repeatMode: Int) { refresh() }
        override fun onPlaybackStateChanged(playbackState: Int) { refresh() }
    }

    private fun refresh() {
        val c = controller ?: return
        val md: MediaMetadata? = c.mediaMetadata
        val queue = (0 until c.mediaItemCount).map { i ->
            val mi = c.getMediaItemAt(i)
            mi.mediaId to (mi.mediaMetadata.title?.toString() ?: mi.mediaId)
        }
        val newArtworkKey = c.currentMediaItem?.localConfiguration?.uri?.path?.let { "art://$it" }
        if (newArtworkKey != _state.value.artworkKey) {
            com.atmosplayer.util.Trace.log("currentArtwork updated: $newArtworkKey (localUri=${c.currentMediaItem?.localConfiguration?.uri})")
        }
        _state.value = _state.value.copy(
            isPlaying = c.isPlaying,
            currentTrackId = c.currentMediaItem?.mediaId,
            title = md?.title?.toString() ?: "",
            artist = md?.artist?.toString() ?: "",
            album = md?.albumTitle?.toString() ?: "",
            artworkKey = newArtworkKey,
            durationMs = c.duration.coerceAtLeast(0),
            audioInfo = if (c.playbackState != Player.STATE_IDLE) FormatInspector.fromPlayer(c)
                        else _state.value.audioInfo,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            queueTitles = queue
        )
    }

    private fun startPositionTicker() {
        scope.launch {
            while (isActive) {
                controller?.let { c ->
                    if (c.isPlaying) {
                        _state.value = _state.value.copy(positionMs = c.currentPosition)
                    }
                }
                delay(200)
            }
        }
        scope.launch {
            while (isActive) {
                delay(10_000)
                persistCurrent()
            }
        }
    }

    private fun persistCurrent() {
        scope.launch {
            // === 主线程：读取 MediaController 全部状态（Media3 强制要求应用线程调用）===
            val c = controller ?: return@launch
            val index = c.currentMediaItemIndex.coerceAtLeast(0)
            val positionMs = c.currentPosition.coerceAtLeast(0)
            val ids = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }

            // === IO 线程：仅做数据库写入 ===
            withContext(Dispatchers.IO) {
                stateDao.save(PlaybackStateEntity(
                    queueTrackIds = ids.joinToString(","),
                    currentIndex = index,
                    positionMs = positionMs
                ))
            }
        }
    }

    private fun persistQueue(tracks: List<TrackEntity>, index: Int, pos: Long) {
        scope.launch(Dispatchers.IO) {
            stateDao.save(PlaybackStateEntity(
                queueTrackIds = tracks.joinToString(",") { it.id },
                currentIndex = index, positionMs = pos
            ))
        }
    }

    private fun restoreState() {
        scope.launch(Dispatchers.IO) {
            val s = stateDao.get() ?: return@launch
            val ids = s.queueTrackIds.split(",").filter { it.isNotBlank() }
            if (ids.isEmpty()) return@launch
            val tracks = trackDao.byIds(ids)
            val ordered = ids.mapNotNull { id -> tracks.find { it.id == id } }
            if (ordered.isEmpty()) return@launch
            launch(Dispatchers.Main) {
                val c = controller ?: return@launch
                if (c.mediaItemCount == 0) {
                    c.setMediaItems(ordered.map { it.toMediaItem() },
                        s.currentIndex.coerceIn(0, ordered.size - 1), s.positionMs)
                    c.prepare()   // 恢复但不自动播放
                    refresh()
                }
            }
        }
    }
}

fun TrackEntity.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id)
        .setUri(android.net.Uri.fromFile(java.io.File(path)))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title).setArtist(artist).setAlbumTitle(album)
                // 不设 artworkUri：真机日志显示音频路径会被 MediaSessionLegacyStub 当图片反复解码报错。
                // 封面统一走 UI 层 Coil art:// fetcher。
                .build()
        )
        .build()
