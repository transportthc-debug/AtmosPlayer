package com.atmosplayer.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 设置主页：菜单式入口（扫描目录管理 / 杜比能力检测 / 关于） */
@Composable
fun SettingsScreen(
    scanMode: Int,
    onOpenScanFolders: () -> Unit,
    onOpenDolbyCheck: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
            .padding(bottom = 170.dp) // 让位给悬浮玻璃底栏
    ) {
        Text("设置", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(
            "版本 ${com.atmosplayer.BuildConfig.VERSION_NAME} (code ${com.atmosplayer.BuildConfig.VERSION_CODE})",
            fontSize = 12.sp, color = Color.White.copy(alpha = 0.45f)
        )
        Spacer(Modifier.height(20.dp))

        Text("扫描与曲库", fontSize = 13.sp, color = Color.White.copy(alpha = 0.5f))
        Spacer(Modifier.height(6.dp))
        MenuRow(
            icon = Icons.Rounded.Folder,
            title = "扫描目录管理",
            subtitle = when (scanMode) {
                1 -> "白名单模式 · 仅扫描列出目录"
                2 -> "黑名单模式 · 排除列出目录"
                else -> "全盘扫描"
            },
            onClick = onOpenScanFolders
        )

        Spacer(Modifier.height(20.dp))
        Text("音频", fontSize = 13.sp, color = Color.White.copy(alpha = 0.5f))
        Spacer(Modifier.height(6.dp))
        MenuRow(
            icon = Icons.Rounded.SurroundSound,
            title = "杜比能力检测",
            subtitle = "解码 / 直通 / 系统渲染 分级报告",
            onClick = onOpenDolbyCheck
        )

        Spacer(Modifier.height(20.dp))
        Text("其他", fontSize = 13.sp, color = Color.White.copy(alpha = 0.5f))
        Spacer(Modifier.height(6.dp))
        MenuRow(
            icon = Icons.Rounded.Info,
            title = "关于 AtmosPlayer",
            subtitle = "版本 / 开源组件 / 反馈",
            onClick = onOpenAbout
        )
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.8f))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text(subtitle, color = Color.White.copy(alpha = 0.45f), fontSize = 12.sp)
        }
        Icon(
            Icons.AutoMirrored.Rounded.KeyboardArrowRight, null,
            tint = Color.White.copy(alpha = 0.4f)
        )
    }
    HorizontalDivider(color = Color.White.copy(alpha = 0.06f))
}
