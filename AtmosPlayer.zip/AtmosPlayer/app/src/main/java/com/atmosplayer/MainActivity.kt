package com.atmosplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.util.UnstableApi
import com.atmosplayer.ui.components.MiniPlayer
import com.atmosplayer.ui.library.LibraryScreen
import com.atmosplayer.ui.library.LibraryViewModel
import com.atmosplayer.ui.player.NowPlayingScreen
import com.atmosplayer.ui.player.PlayerViewModel
import com.atmosplayer.ui.settings.AboutScreen
import com.atmosplayer.ui.settings.DolbyCheckScreen
import com.atmosplayer.ui.settings.ScanFoldersScreen
import com.atmosplayer.ui.settings.SettingsScreen
import com.atmosplayer.ui.theme.AtmosTheme
import dagger.hilt.android.AndroidEntryPoint
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.hazeEffect

@UnstableApi
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AtmosTheme(dark = true) {
                Root()
            }
        }
    }
}

@UnstableApi
@Composable
private fun Root() {
    val context = LocalContext.current
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val audioPermission = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        // 必须以"音频读取权限"为准：只给通知/视频权限不能放行，否则扫描时 SecurityException 闪退
        hasPermission = grants[audioPermission] == true ||
            ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED
    }

    if (!hasPermission) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B0B10)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("需要媒体访问权限以扫描本地音乐", color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                val perms = buildList {
                    if (Build.VERSION.SDK_INT >= 33) {
                        add(Manifest.permission.READ_MEDIA_AUDIO)
                        add(Manifest.permission.READ_MEDIA_VIDEO)
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
                }.toTypedArray()
                launcher.launch(perms)
            }) { Text("授权") }
        }
        return
    }

    val libraryVm: LibraryViewModel = hiltViewModel()
    val playerVm: PlayerViewModel = hiltViewModel()
    val playerState by playerVm.player.collectAsState()
    val dolbyReport by playerVm.dolbyReport.collectAsState()

    var nowPlayingOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    // 设置子页面：0=设置主页 1=扫描目录管理 2=杜比能力检测 3=关于
    var settingsPage by remember { mutableStateOf(0) }
    val hazeState = remember { dev.chrisbanes.haze.HazeState() }

    LaunchedEffect(Unit) {
        // 启动时清空歌词缓存：编码识别与内嵌读取已升级，旧缓存可能挡歌词
        runCatching { libraryVm.clearLyricsCache() }
        libraryVm.scan()
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10))) {
        // ---- 内容层：全屏延伸到底栏背后，作为 Haze 模糊源 ----
        Box(
            Modifier
                .fillMaxSize()
                .hazeSource(hazeState)
                // 注意：这里绝不能让 padding——内容必须延伸到悬浮底栏背后，Haze 才有东西可模糊。
                // 列表底部的让位 padding 在各列表的 contentPadding 里加。
        ) {
            when (tab) {
                0 -> LibraryScreen(libraryVm, playerState)
                else -> when (settingsPage) {
                    1 -> ScanFoldersScreen(vm = libraryVm, onBack = { settingsPage = 0 })
                    2 -> DolbyCheckScreen(
                        report = dolbyReport,
                        onRedetect = { playerVm.redetectDolby() },
                        onBack = { settingsPage = 0 }
                    )
                    3 -> AboutScreen(onBack = { settingsPage = 0 })
                    else -> {
                        val scanMode by libraryVm.scanMode.collectAsState()
                        SettingsScreen(
                            scanMode = scanMode,
                            onOpenScanFolders = { settingsPage = 1 },
                            onOpenDolbyCheck = { settingsPage = 2 },
                            onOpenAbout = { settingsPage = 3 }
                        )
                    }
                }
            }
        }

        // ---- 悬浮液态玻璃底栏：真正模糊背后的列表内容 ----
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            MiniPlayer(
                state = playerState,
                onClick = { nowPlayingOpen = true },
                onToggle = { playerVm.playerManager.togglePlay() },
                onNext = { playerVm.playerManager.next() },
                hazeState = hazeState
            )
            NavigationBar(
                containerColor = Color.Transparent,
                modifier = Modifier.hazeEffect(
                    state = hazeState,
                    style = dev.chrisbanes.haze.HazeStyle(
                        backgroundColor = Color(0xCC14141E),
                        tint = dev.chrisbanes.haze.HazeTint(Color.Black.copy(alpha = 0.30f)),
                        blurRadius = 32.dp
                    )
                )
            ) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0; settingsPage = 0 },
                    icon = { Icon(Icons.Rounded.LibraryMusic, null) },
                    label = { Text("曲库") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1; settingsPage = 0 },
                    icon = { Icon(Icons.Rounded.Settings, null) },
                    label = { Text("设置") }
                )
            }
        }

        // 全屏播放页覆盖层
        AnimatedContent(targetState = nowPlayingOpen, label = "np") { open ->
            if (open) {
                NowPlayingScreen(vm = playerVm, onClose = { nowPlayingOpen = false })
            }
        }
    }
}
