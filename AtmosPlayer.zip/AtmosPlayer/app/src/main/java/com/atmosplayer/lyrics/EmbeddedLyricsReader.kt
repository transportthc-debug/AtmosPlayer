package com.atmosplayer.lyrics

import java.io.RandomAccessFile
import java.nio.charset.Charset

/**
 * 非 MP4 容器内嵌歌词读取（Lyrico/TagLib 的写入位置）：
 * - FLAC: metadata block type=4 (VorbisComment)，键 LYRICS / ©LYR / UNSYNCEDLYRICS
 * - MP3: ID3v2.3/v2.4 USLT 帧（非同步歌词）
 * 全部容错：解析失败返回 null，不影响任何主流程。
 */
object EmbeddedLyricsReader {

    fun read(path: String): String? {
        val lower = path.lowercase()
        return when {
            lower.endsWith(".flac") -> readFlac(path)
            lower.endsWith(".mp3") -> readMp3(path)
            else -> null
        }
    }

    // ---------------- FLAC ----------------
    private fun readFlac(path: String): String? = runCatching {
        RandomAccessFile(path, "r").use { f ->
            val magic = ByteArray(4); f.readFully(magic)
            if (String(magic, Charsets.US_ASCII) != "fLaC") return null
            var last = false
            while (!last) {
                val header = f.read()
                if (header < 0) return null
                last = (header and 0x80) != 0
                val type = header and 0x7F
                val len = (f.read() shl 16) or (f.read() shl 8) or f.read()
                if (len < 0 || f.filePointer + len > f.length()) return null
                if (type == 4) { // VORBIS_COMMENT
                    val block = ByteArray(len); f.readFully(block)
                    return parseVorbisComment(block)
                }
                f.skipBytes(len)
            }
            null
        }
    }.getOrNull()

    private fun parseVorbisComment(block: ByteArray): String? = runCatching {
        fun leInt(b: ByteArray, off: Int) =
            (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or ((b[off + 3].toInt() and 0xFF) shl 24)
        var pos = 0
        val vendorLen = leInt(block, pos); pos += 4 + vendorLen
        val count = leInt(block, pos); pos += 4
        repeat(count.coerceAtMost(2000)) {
            val l = leInt(block, pos); pos += 4
            if (pos + l > block.size) return null
            val entry = String(block, pos, l, Charsets.UTF_8); pos += l
            val eq = entry.indexOf('=')
            if (eq > 0) {
                val key = entry.substring(0, eq).uppercase()
                if (key == "LYRICS" || key == "©LYR" || key == "UNSYNCEDLYRICS" || key == "UNSYNCED LYRICS") {
                    return entry.substring(eq + 1).takeIf { it.isNotBlank() }
                }
            }
        }
        null
    }.getOrNull()

    // ---------------- MP3 (ID3v2) ----------------
    private fun readMp3(path: String): String? = runCatching {
        RandomAccessFile(path, "r").use { f ->
            val id3 = ByteArray(10); f.readFully(id3)
            if (id3[0] != 'I'.code.toByte() || id3[1] != 'D'.code.toByte() || id3[2] != '3'.code.toByte()) return null
            val major = id3[3].toInt()
            val flags = id3[5].toInt()
            val tagSize = syncsafe(id3, 6)
            val tagEnd = 10L + tagSize
            var pos = 10L
            // 扩展头跳过
            if ((flags and 0x40) != 0) {
                f.seek(pos)
                val extSize = if (major == 4) { val b = ByteArray(4); f.readFully(b); syncsafe(b, 0) }
                    else f.readInt()
                pos += (if (major == 4) extSize else extSize + 4)
            }
            while (pos + 10 <= tagEnd && pos + 10 <= f.length()) {
                f.seek(pos)
                val fh = ByteArray(10); f.readFully(fh)
                val frameId = String(fh, 0, 4, Charsets.ISO_8859_1)
                if (frameId[0].code == 0) break
                val frameSize = if (major == 4) syncsafe(fh, 4)
                    else ((fh[4].toInt() and 0xFF) shl 24) or ((fh[5].toInt() and 0xFF) shl 16) or
                         ((fh[6].toInt() and 0xFF) shl 8) or (fh[7].toInt() and 0xFF)
                if (frameSize <= 0 || frameSize > 8 * 1024 * 1024) break
                if (frameId == "USLT") {
                    val body = ByteArray(frameSize); f.readFully(body)
                    return parseUslt(body)
                }
                pos += 10 + frameSize
            }
            null
        }
    }.getOrNull()

    private fun syncsafe(b: ByteArray, off: Int) =
        ((b[off].toInt() and 0x7F) shl 21) or ((b[off + 1].toInt() and 0x7F) shl 14) or
        ((b[off + 2].toInt() and 0x7F) shl 7) or (b[off + 3].toInt() and 0x7F)

    /** USLT: encoding(1) + language(3) + 描述(按编码 null 结尾) + 正文 */
    private fun parseUslt(body: ByteArray): String? = runCatching {
        if (body.size < 5) return null
        val enc = body[0].toInt()
        val charset = when (enc) {
            1 -> Charset.forName("UTF-16")
            2 -> Charset.forName("UTF-16BE")
            3 -> Charsets.UTF_8
            else -> Charset.forName("GB18030")  // enc=0 ISO-8859-1，但国内工具常直接塞 GBK → 用 GB18030 兼容
        }
        var pos = 4
        // 跳过描述字段（null 结尾；UTF-16 系是双字节 00 00）
        pos = when (enc) {
            1, 2 -> {
                var p = pos
                while (p + 1 < body.size && !(body[p].toInt() == 0 && body[p + 1].toInt() == 0)) p += 2
                p + 2
            }
            else -> {
                var p = pos
                while (p < body.size && body[p].toInt() != 0) p++
                p + 1
            }
        }
        if (pos >= body.size) return null
        // enc=0 的字节先用 GB18030 试，失败换 ISO-8859-1
        if (enc == 0) {
            val raw = body.copyOfRange(pos, body.size)
            return TextDecoder.decode(raw).trim().takeIf { it.isNotBlank() }
        }
        String(body, pos, body.size - pos, charset).trim().takeIf { it.isNotBlank() }
    }.getOrNull()
}
