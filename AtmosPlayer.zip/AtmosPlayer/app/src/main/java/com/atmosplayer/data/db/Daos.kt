package com.atmosplayer.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    @Upsert suspend fun upsertAll(tracks: List<TrackEntity>)
    @Query("DELETE FROM tracks") suspend fun clear()

    @Query("SELECT * FROM tracks ORDER BY title COLLATE LOCALIZED") fun allTracks(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE id = :id") suspend fun byId(id: String): TrackEntity?
    @Query("SELECT * FROM tracks WHERE id IN (:ids)") suspend fun byIds(ids: List<String>): List<TrackEntity>
    @Query("SELECT * FROM tracks WHERE album = :album ORDER BY title") fun byAlbum(album: String): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE artist = :artist ORDER BY album, title") fun byArtist(artist: String): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE folder = :folder ORDER BY title") fun byFolder(folder: String): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE isFavorite = 1 ORDER BY title") fun favorites(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE lastPlayed IS NOT NULL ORDER BY lastPlayed DESC LIMIT 100") fun recentlyPlayed(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE isDolbyAtmos = 1 ORDER BY title") fun atmosTracks(): Flow<List<TrackEntity>>
    @Query("SELECT * FROM tracks WHERE title LIKE '%'||:q||'%' OR artist LIKE '%'||:q||'%' OR album LIKE '%'||:q||'%' ORDER BY title")
    fun search(q: String): Flow<List<TrackEntity>>

    @Query("UPDATE tracks SET isFavorite = :fav WHERE id = :id") suspend fun setFavorite(id: String, fav: Boolean)
    @Query("UPDATE tracks SET lastPlayed = :ts, playCount = playCount + 1 WHERE id = :id")
    suspend fun markPlayed(id: String, ts: Long)
    @Query("UPDATE tracks SET animatedArtworkPath = :path WHERE id = :id")
    suspend fun setAnimatedArtwork(id: String, path: String?)
    @Query("SELECT COUNT(*) FROM tracks") suspend fun count(): Int
    /** 移除某文件夹（含子目录）的全部曲目 */
    @Query("DELETE FROM tracks WHERE folder = :folder OR folder LIKE :folder || '/%'")
    suspend fun deleteFolder(folder: String): Int
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun all(): Flow<List<PlaylistEntity>>
    @Insert suspend fun create(p: PlaylistEntity): Long
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun delete(id: Long)
    @Upsert suspend fun addEntries(entries: List<PlaylistEntry>)
    @Query("SELECT t.* FROM tracks t INNER JOIN playlist_entries e ON t.id = e.trackId WHERE e.playlistId = :pid ORDER BY e.position")
    fun tracksOf(pid: Long): Flow<List<TrackEntity>>
}

@Dao
interface PlaybackStateDao {
    @Query("SELECT * FROM playback_state WHERE id = 1") suspend fun get(): PlaybackStateEntity?
    @Upsert suspend fun save(state: PlaybackStateEntity)
}

@Dao
interface LyricsDao {
    @Query("SELECT * FROM lyric_offsets WHERE trackId = :id") suspend fun offset(id: String): LyricOffsetEntity?
    @Upsert suspend fun saveOffset(e: LyricOffsetEntity)
    @Query("SELECT * FROM lyrics_cache WHERE trackId = :id") suspend fun cache(id: String): LyricsCacheEntity?
    @Upsert suspend fun saveCache(e: LyricsCacheEntity)
    @Query("DELETE FROM lyrics_cache") suspend fun clearCache()
}
