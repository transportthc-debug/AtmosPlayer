package com.atmosplayer.library

import android.content.Context
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.MetadataRetriever
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.atmosplayer.data.db.TrackDao
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.lyrics.Mp4AtomReader
import com.atmosplayer.playback.DolbyCapabilities
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LibraryRepository @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val trackDao: TrackDao,
    private val settings: com.atmosplayer.data.SettingsRepository
) {
    val tracks: Flow<List<TrackEntity>> = trackDao.allTracks()
    val favorites: Flow<List<TrackEntity>> = trackDao.favorites()
    val recent: Flow<List<TrackEntity>> = trackDao.recentlyPlayed()
    val atmosTracks: Flow<List<TrackEntity>> = trackDao.atmosTracks()

    fun byAlbum(album: String) = trackDao.byAlbum(album)
    fun byArtist(artist: String) = trackDao.byArtist(artist)
    fun byFolder(folder: String) = trackDao.byFolder(folder)
    fun search(q: String) = trackDao.search(q)

    suspend fun toggleFavorite(id: String, fav: Boolean) = trackDao.setFavorite(id, fav)
    suspend fun markPlayed(id: String) = trackDao.markPlayed(id, System.currentTimeMillis())

    /** 移除某文件夹（含子目录）的全部曲目 */
    suspend fun removeFolder(folder: String): Int {
        val n = trackDao.deleteFolder(folder)
        com.atmosplayer.util.Trace.log("scan: removed folder $folder ($n tracks)")
        return n
    }

    /**
     * 范围过滤（OuterTune 语义）：
     * - 白名单模式：只收白名单目录内的歌，但黑名单可继续排除其中的子目录
     * - 黑名单模式：全盘收歌，排除黑名单目录（含子目录）
     * - 全盘模式：不过滤
     */
    private fun inScope(path: String, mode: Int, white: Set<String>, black: Set<String>): Boolean {
        fun under(dir: String) = path == dir || path.startsWith(dir.trimEnd('/') + "/")
        if (black.any { under(it) }) return false          // 黑名单永远优先生效
        return when (mode) {
            1 -> white.any { under(it) }                   // 白名单：只收列出的目录
            else -> true                                   // 0=全盘 2=黑名单（黑名单已在上面生效）
        }
    }

    /** 扫描：MediaStore 音频 → 范围过滤 → 逐文件 Media3 MetadataRetriever 读取真实编码参数 */
    @UnstableApi
    suspend fun scan(): Int = withContext(Dispatchers.IO) {
        val mode = settings.scanMode.first()
        val white = settings.scanWhitelist.first()
        val black = settings.scanBlacklist.first()
        val modeName = when (mode) { 1 -> "白名单"; 2 -> "黑名单"; else -> "全盘" }
        com.atmosplayer.util.Trace.log("scan: mode=$modeName white=$white black=$black")

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.GENRE
        )
        val items = mutableListOf<TrackEntity>()
        val cursor = runCatching {
            ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            MediaStore.Audio.Media.DATE_ADDED + " DESC"
            )
        }.onFailure { android.util.Log.e("AtmosPlayer", "MediaStore query failed", it) }
            .getOrNull()
        cursor?.use { c ->
            while (c.moveToNext()) {
                val path = c.getString(1) ?: continue
                if (!inScope(path, mode, white, black)) continue   // 范围过滤：不进库
                if (!File(path).exists()) continue
                val ext = path.substringAfterLast('.', "").lowercase()
                if (ext !in setOf("m4a","mp3","flac","wav","aac","alac","ogg","opus","ec3","ac3","ac4","eac3","mp4")) continue

                val base = TrackEntity(
                    id = sha1(path),
                    path = path,
                    title = c.getString(2) ?: File(path).nameWithoutExtension,
                    artist = c.getString(3) ?: "未知艺术家",
                    album = c.getString(4) ?: "未知专辑",
                    genre = runCatching { c.getString(7) }.getOrNull(),
                    folder = File(path).parent ?: "/",
                    durationMs = c.getLong(5),
                    dateAdded = c.getLong(6) * 1000
                )
                items += enrich(base)
            }
        }
        // 全量重建：不在新范围内的旧数据随 clear 一并清掉
        trackDao.clear()
        trackDao.upsertAll(items)
        com.atmosplayer.util.Trace.log("scan: done, indexed=${items.size}")
        items.size
    }

    /** 用 Media3 读取真实音频参数（mime/码率/采样率/声道），并探测内嵌歌词与同名动态封面 */
    @UnstableApi
    private fun enrich(t: TrackEntity): TrackEntity {
        var mime: String? = null
        var bitrate = 0
        var sampleRate = 0
        var channels = 0
        try {
            val future = MetadataRetriever.retrieveMetadata(
                DefaultMediaSourceFactory(ctx),
                MediaItem.fromUri(android.net.Uri.fromFile(File(t.path)))
            )
            val groups = future.get()
            outer@ for (i in 0 until groups.length) {
                val g = groups.get(i)
                if (g.type != androidx.media3.common.C.TRACK_TYPE_AUDIO) continue
                for (j in 0 until g.length) {
                    val f = g.getFormat(j)
                    mime = f.sampleMimeType
                    bitrate = f.bitrate
                    sampleRate = f.sampleRate
                    channels = f.channelCount
                    break@outer
                }
            }
        } catch (e: Exception) { /* 探测失败不影响入库 */ }

        val isM4a = t.path.endsWith(".m4a", true) || t.path.endsWith(".mp4", true)
        val embeddedLyrics = if (isM4a) {
            Mp4AtomReader.read(t.path).lyricsRaw?.isNotBlank() == true
        } else false

        // 同名动态封面视频自动识别
        val f = File(t.path)
        val videoCandidates = listOf(
            File(f.parentFile, f.nameWithoutExtension + ".art.mp4"),
            File(f.parentFile, f.nameWithoutExtension + ".mp4"),
            File(f.parentFile, f.nameWithoutExtension + ".art.mov")
        )
        val video = videoCandidates.firstOrNull { it.exists() }?.absolutePath

        val atmos = DolbyCapabilities.isAtmosMime(mime)
        return t.copy(
            bitrate = bitrate, sampleRate = sampleRate, codecMime = mime,
            channelLayout = if (atmos) "Immersive" else if (channels > 0) "${channels}ch" else null,
            isDolbyAtmos = atmos,
            hasEmbeddedLyrics = embeddedLyrics,
            hasWordLyrics = embeddedLyrics,
            artworkPath = t.path,
            animatedArtworkPath = video
        )
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
