package com.atmosplayer.di

import android.content.Context
import androidx.room.Room
import com.atmosplayer.data.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "atmosplayer.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun trackDao(db: AppDatabase) = db.trackDao()
    @Provides fun playlistDao(db: AppDatabase) = db.playlistDao()
    @Provides fun playbackStateDao(db: AppDatabase) = db.playbackStateDao()
    @Provides fun lyricsDao(db: AppDatabase) = db.lyricsDao()
}
