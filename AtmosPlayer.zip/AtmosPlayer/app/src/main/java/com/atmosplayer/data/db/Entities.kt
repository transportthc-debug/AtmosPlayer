package com.atmosplayer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,            // sha1(path)
    val path: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String? = null,
    val genre: String? = null,
    val folder: String,
    val durationMs: Long = 0,
    val bitrate: Int = 0,
    val sampleRate: Int = 0,
    val codecMime: String? = null,         // audio/ac4, audio/eac3-joc ...
    val channelLayout: String? = null,
    val isDolbyAtmos: Boolean = false,
    val hasEmbeddedLyrics: Boolean = false,
    val hasWordLyrics: Boolean = false,
    val artworkPath: String? = null,
    val animatedArtworkPath: String? = null,
    val dateAdded: Long = 0,
    val lastPlayed: Long? = null,
    val playCount: Int = 0,
    val isFavorite: Boolean = false
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_entries", primaryKeys = ["playlistId", "trackId"])
data class PlaylistEntry(
    val playlistId: Long,
    val trackId: String,
    val position: Int
)

@Entity(tableName = "playback_state")
data class PlaybackStateEntity(
    @PrimaryKey val id: Int = 1,
    val queueTrackIds: String = "",       // comma separated
    val currentIndex: Int = 0,
    val positionMs: Long = 0
)

@Entity(tableName = "lyric_offsets")
data class LyricOffsetEntity(
    @PrimaryKey val trackId: String,
    val offsetMs: Long
)

@Entity(tableName = "lyrics_cache")
data class LyricsCacheEntity(
    @PrimaryKey val trackId: String,
    val source: String,                    // EMBEDDED / TTML_FILE / LRC_FILE / NONE
    val rawContent: String?,
    val isWordTimed: Boolean,
    val parsedAt: Long = System.currentTimeMillis()
)
