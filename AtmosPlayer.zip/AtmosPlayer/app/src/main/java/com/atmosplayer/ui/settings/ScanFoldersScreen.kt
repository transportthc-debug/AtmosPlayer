package com.atmosplayer.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosplayer.ui.components.glassSurface
import com.atmosplayer.ui.library.LibraryViewModel

/**
 * 扫描目录管理（参考 OuterTune Local Media 语义）：
 * - 全盘 / 白名单 / 黑名单 三模式
 * - 白名单模式只扫描列出目录；黑名单永远优先生效（可在白名单内排除子目录）
 * - 修改范围后重扫，旧数据库中范围外歌曲随全量重建清除
 */
@Composable
fun ScanFoldersScreen(vm: LibraryViewModel, onBack: () -> Unit) {
    val mode by vm.scanMode.collectAsState()
    val whitelist by vm.scanWhitelist.collectAsState()
    val blacklist by vm.scanBlacklist.collectAsState()
    val scanning by vm.scanning.collectAsState()

    var addWhiteDialog by remember { mutableStateOf(false) }
    var addBlackDialog by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
            .padding(bottom = 170.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Color.White) }
            Text("扫描目录管理", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(12.dp))

        // ---- 扫描模式 ----
        SectionTitle("扫描模式")
        val modes = listOf(0 to "全盘扫描", 1 to "白名单模式", 2 to "黑名单模式")
        modes.forEach { (m, label) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { vm.setScanMode(m) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = mode == m, onClick = { vm.setScanMode(m) })
                Column {
                    Text(label, color = Color.White, fontSize = 15.sp)
                    Text(
                        when (m) {
                            0 -> "扫描设备上所有音频文件"
                            1 -> "只扫描下方白名单目录"
                            else -> "扫描全盘，但排除下方黑名单目录"
                        },
                        color = Color.White.copy(alpha = 0.45f), fontSize = 12.sp
                    )
                }
            }
        }

        // ---- 白名单 ----
        SectionTitle("白名单目录（${whitelist.size}）")
        whitelist.forEach { path ->
            FolderRow(path, onRemove = { vm.removeWhitelist(path) })
        }
        TextButton(onClick = { addWhiteDialog = true }) {
            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("添加白名单目录")
        }

        // ---- 黑名单 ----
        SectionTitle("屏蔽目录（${blacklist.size}）")
        blacklist.forEach { path ->
            FolderRow(path, onRemove = { vm.removeBlacklist(path) })
        }
        TextButton(onClick = { addBlackDialog = true }) {
            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("添加屏蔽目录")
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.scan() },
            enabled = !scanning,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (scanning) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("扫描中…")
            } else Text("按当前范围重新扫描")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "提示：修改扫描范围后需要重新扫描，范围外的旧歌曲会从曲库中清除。黑名单在两种模式下都优先生效。",
            color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp, lineHeight = 17.sp
        )
    }

    if (addWhiteDialog) {
        AddFolderDialog(
            title = "添加白名单目录",
            onDismiss = { addWhiteDialog = false },
            onAdd = { vm.addWhitelist(it); addWhiteDialog = false }
        )
    }
    if (addBlackDialog) {
        AddFolderDialog(
            title = "添加屏蔽目录",
            onDismiss = { addBlackDialog = false },
            onAdd = { vm.addBlacklist(it); addBlackDialog = false }
        )
    }
}

@Composable
private fun SectionTitle(t: String) {
    Spacer(Modifier.height(14.dp))
    Text(t, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
        fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun FolderRow(path: String, onRemove: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .glassSurface(shape = RoundedCornerShape(10.dp), tint = Color.White.copy(alpha = 0.07f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Folder, null, tint = Color.White.copy(alpha = 0.6f),
            modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(path, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Rounded.Close, null, tint = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun AddFolderDialog(title: String, onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var path by remember { mutableStateOf("") }
    val suggestions = listOf(
        "/storage/emulated/0/DolbyAt",
        "/storage/emulated/0/Music",
        "/storage/emulated/0/Download",
        "/storage/emulated/0/GAMESHUB"
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = path, onValueChange = { path = it },
                    label = { Text("目录绝对路径") }, singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Text("常用目录：", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
                suggestions.forEach { s ->
                    Text(
                        s, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clickable { path = s }
                            .padding(vertical = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (path.isNotBlank()) onAdd(path.trim().trimEnd('/')) }) {
                Text("添加")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}
