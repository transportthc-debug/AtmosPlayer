package com.atmosplayer.lyrics

/**
 * 增强型 LRC（逐词）解析器。
 * 兼容 Apple/QQ音乐风格：
 *   [00:28.714]<00:28.714>All <00:28.889>white <00:29.058>Gucci ...
 *   [00:28.714]身穿白色古驰套装...      <- 同时间戳第二行 = 上一行的翻译
 * 也兼容标准 LRC 逐行格式与多时间戳重复行。
 */
object EnhancedLrcParser {

    private val lineTime = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val wordTime = Regex("""<(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?>""")
    private val metaTag = Regex("""\[(ti|ar|al|by|offset|re|ve|length):.*]""", RegexOption.IGNORE_CASE)

    fun canParse(raw: String): Boolean =
        raw.lineSequence().any { lineTime.containsMatchIn(it) }

    fun parse(raw: String): Lyrics {
        val offset = Regex("""\[offset:\s*([+-]?\d+)\s*]""").find(raw)
            ?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        data class Raw(val startMs: Long, val body: String)
        val raws = mutableListOf<Raw>()
        for (line in raw.lineSequence()) {
            val t = line.trim()
            if (t.isEmpty() || metaTag.matches(t)) continue
            val stamps = lineTime.findAll(t).toList()
            if (stamps.isEmpty()) continue
            val body = t.substring(stamps.last().range.last + 1)
            if (wordTime.containsMatchIn(body) || body.isNotBlank()) {
                for (s in stamps) raws += Raw(toMs(s), body)
            }
        }
        raws.sortBy { it.startMs }

        // 合并：同一 startMs 的第二段视为上一行的翻译
        val merged = mutableListOf<Pair<Long, MutableList<String>>>()
        for (r in raws) {
            if (merged.isNotEmpty() && merged.last().first == r.startMs) {
                merged.last().second.add(r.body)
            } else {
                merged += r.startMs to mutableListOf(r.body)
            }
        }

        var anyWord = false
        val lines = mutableListOf<LyricLine>()
        for (i in merged.indices) {
            val (start, bodies) = merged[i]
            val main = bodies.first()
            val translation = bodies.drop(1).firstOrNull { !wordTime.containsMatchIn(it) }
                ?: bodies.drop(1).firstOrNull()?.let { wordTime.replace(it, "") }
            val end = if (i + 1 < merged.size) merged[i + 1].first else start + 5_000

            val words = mutableListOf<LyricWord>()
            val matches = wordTime.findAll(main).toList()
            if (matches.isNotEmpty()) {
                anyWord = true
                for (w in matches.indices) {
                    val m = matches[w]
                    val wStart = toMs(m)
                    val textStart = m.range.last + 1
                    val textEnd = if (w + 1 < matches.size) matches[w + 1].range.first else main.length
                    val wEnd = if (w + 1 < matches.size) toMs(matches[w + 1]) else end
                    val text = main.substring(textStart, textEnd)
                    if (text.isNotEmpty()) words += LyricWord(text, wStart - offset, wEnd - offset)
                }
            } else {
                words += LyricWord(main, start - offset, end - offset)
            }
            lines += LyricLine(start - offset, end - offset, words, translation?.trim())
        }
        return Lyrics(lines, LyricSource.LRC_FILE, anyWord)
    }

    private fun toMs(m: MatchResult): Long {
        val min = m.groupValues[1].toLong()
        val sec = m.groupValues[2].toLong()
        val fracRaw = m.groupValues.getOrNull(3) ?: ""
        val frac = when (fracRaw.length) {
            1 -> fracRaw.toLong() * 100
            2 -> fracRaw.toLong() * 10
            3 -> fracRaw.toLong()
            else -> 0L
        }
        return (min * 60 + sec) * 1000 + frac
    }
}
