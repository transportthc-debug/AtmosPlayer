package com.atmosplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * 液态玻璃视觉模拟（Android 无系统级 Liquid Glass，以下效果均为合成层模拟）：
 * 半透明底色 + 顶部高光渐变 + 边缘反光描边。背景模糊由调用方在背景层做 blur。
 */
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(28.dp),
    tint: Color = Color.White.copy(alpha = 0.10f),
    borderAlpha: Float = 0.28f,
    highlight: Boolean = true
): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                tint.copy(alpha = tint.alpha + 0.06f),
                tint
            )
        )
    )
    .then(
        if (highlight) Modifier.background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.12f), Color.Transparent),
                startY = 0f, endY = 60f
            )
        ) else Modifier
    )
    .border(
        width = 1.dp,
        brush = Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = borderAlpha),
                Color.White.copy(alpha = borderAlpha * 0.25f)
            )
        ),
        shape = shape
    )

/** 玻璃光晕背景：封面取色径向光斑 */
@Composable
fun GlassGlowBackground(colors: List<Color>, modifier: Modifier = Modifier) {
    Box(modifier.background(Color(0xFF0B0B10))) {
        Box(
            Modifier
                .matchParentSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            colors.getOrElse(0) { Color(0xFF3D1D6E) }.copy(alpha = 0.55f),
                            Color.Transparent
                        ),
                        radius = 1400f
                    )
                )
        )
        Box(
            Modifier
                .matchParentSize()
                .background(
                    Brush.linearGradient(
                        listOf(
                            colors.getOrElse(1) { Color(0xFF1B1035) }.copy(alpha = 0.35f),
                            Color.Transparent,
                            colors.getOrElse(0) { Color(0xFF3D1D6E) }.copy(alpha = 0.25f)
                        )
                    )
                )
        )
    }
}

/** 毛玻璃底板（背景图 + blur + 暗化） */
fun Modifier.frostedBackground(): Modifier = this
    .blur(80.dp)
    .background(Color.Black.copy(alpha = 0.45f))
