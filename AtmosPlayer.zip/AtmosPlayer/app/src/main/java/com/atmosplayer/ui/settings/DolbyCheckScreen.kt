package com.atmosplayer.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.atmosplayer.playback.DolbyCapabilities

/**
 * 杜比能力检测页（参考 Android 官方 audio-capabilities 文档 + media3 AudioCapabilities）。
 * 分级展示：解码支持(MediaCodecList) / 直通支持(AudioTrack.isDirectPlaybackSupported) / 系统杜比渲染。
 * 三个层级互不替代：有 Dolby 解码器 ≠ 完整 Dolby Atmos 渲染。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DolbyCheckScreen(
    report: DolbyCapabilities.Report?,
    onRedetect: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("杜比能力检测") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = { IconButton(onClick = onRedetect) { Icon(Icons.Filled.Refresh, "重新检测") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        ) {
            if (report == null) {
                Text("检测中…", color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                return@Column
            }

            // 总结论（分级，不夸大）
            val verdict = when {
                report.supportsAtmosJoc || report.supportsAc4 ->
                    "本机可解码 Dolby Atmos 码流（${if (report.supportsAc4) "AC-4" else "E-AC-3 JOC"}）"
                report.eac3Decoders.isNotEmpty() || report.ac3Decoders.isNotEmpty() ->
                    "本机支持 Dolby Audio 解码，未检测到 Atmos（JOC/AC-4）解码器"
                else -> "未检测到杜比解码能力"
            }
            Text(verdict, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "注：解码支持 ≠ 全景声渲染。Atmos 空间化渲染依赖系统 Dolby DAP 链路，请在系统设置中确认“杜比全景声”已开启。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.55f),
                modifier = Modifier.padding(top = 4.dp),
            )

            Section("一、解码支持（MediaCodecList）", "能否解码该码流")
            CapRow("Dolby Atmos (E-AC-3 JOC)", report.supportsAtmosJoc, report.eac3JocDecoders)
            CapRow("Dolby Atmos (AC-4)", report.supportsAc4, report.ac4Decoders)
            CapRow("Dolby Digital Plus (E-AC-3)", report.eac3Decoders.isNotEmpty(), report.eac3Decoders)
            CapRow("Dolby Digital (AC-3)", report.ac3Decoders.isNotEmpty(), report.ac3Decoders)

            Section("二、直通支持（AudioTrack.isDirectPlaybackSupported）", "能否不经软解、直接输出压缩码流（HDMI/外接功放场景）")
            CapRow("AC-3 直通", report.directAc3, emptyList())
            CapRow("E-AC-3 直通", report.directEac3, emptyList())
            CapRow("E-AC-3 JOC 直通", report.directEac3Joc, emptyList())
            CapRow("AC-4 直通", report.directAc4, emptyList())

            Section("三、系统杜比渲染（推断）", "存在杜比命名的系统解码器（如 c2.dolby.*），说明系统内置杜比处理链")
            CapRow("系统杜比处理链", report.systemDolbyRendering, emptyList())
            if (report.dolbyNamedDecoders.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().padding(start = 34.dp, top = 2.dp)) {
                    report.dolbyNamedDecoders.forEach {
                        Text("· $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Button(onClick = onRedetect, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Refresh, null, modifier = Modifier.padding(end = 6.dp))
                Text("重新检测")
            }
            Text(
                "检测依据：android.media.MediaCodecList / AudioTrack.isDirectPlaybackSupported（API 29+）。结果已写入 trace.txt（dolby.detect 行）。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.45f),
                modifier = Modifier.padding(top = 10.dp, bottom = 24.dp),
            )
        }
    }
}

@Composable
private fun Section(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
        HorizontalDivider(Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurface.copy(0.08f))
    }
}

@Composable
private fun CapRow(name: String, ok: Boolean, decoders: List<String>) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Filled.CheckCircle else Icons.Outlined.Cancel,
            contentDescription = null,
            tint = if (ok) Color(0xFF66BB6A) else MaterialTheme.colorScheme.onSurface.copy(0.3f),
        )
        Column(Modifier.padding(start = 10.dp)) {
            Text(name, style = MaterialTheme.typography.bodyMedium)
            if (decoders.isNotEmpty()) {
                Text(decoders.joinToString(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.45f))
            } else if (!ok) {
                Text("不支持", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
            }
        }
    }
}
