package com.atmosplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.atmosplayer.ui.components.QualityBadge
import com.atmosplayer.ui.components.QualityBadges

private data class AboutInfo(
    val versionName: String,
    val versionCode: Long,
)

private fun loadAbout(ctx: Context): AboutInfo = runCatching {
    val pi: PackageInfo = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
    @Suppress("DEPRECATION")
    AboutInfo(pi.versionName ?: "unknown", if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong())
}.getOrElse { AboutInfo("unknown", 0) }

private fun openUrl(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun sendFeedback(ctx: Context, version: String) {
    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
        putExtra(Intent.EXTRA_EMAIL, arrayOf("atmospan@users.noreply.github.com"))
        putExtra(Intent.EXTRA_SUBJECT, "AtmosPlayer 反馈 (v$version)")
        putExtra(Intent.EXTRA_TEXT, "\n\n----\n设备: ${android.os.Build.MODEL} / Android ${android.os.Build.VERSION.RELEASE}\n版本: $version")
    }
    runCatching { ctx.startActivity(i) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val info = loadAbout(ctx)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("关于") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { pad ->
        Column(
            modifier = Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(12.dp))
            Text("AtmosPlayer", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
                QualityBadge(QualityBadges.Kind.DOLBY_ATMOS)
                QualityBadge(QualityBadges.Kind.HI_RES)
            }
            // 版本（点击复制）
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 10.dp),
            ) {
                Text("v${info.versionName} (${info.versionCode})", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
                IconButton(onClick = {
                    clip.setText(AnnotatedString("AtmosPlayer v${info.versionName} (${info.versionCode})"))
                    Toast.makeText(ctx, "版本号已复制", Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Filled.ContentCopy, "复制版本号", tint = MaterialTheme.colorScheme.onSurface.copy(0.6f)) }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "面向杜比全景声（Dolby Atmos）本地音乐收藏的 Android 播放器。\n" +
                    "支持逐字卡拉OK歌词、Hi-Res/无损识别、格式信息面板、目录扫描范围管理与杜比能力检测。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.75f),
            )

            AboutDivider()
            AboutRow("作者", "atmospan")
            AboutRow("项目主页", "github.com/atmospan/AtmosPlayer", onClick = { openUrl(ctx, "https://github.com/atmospan/AtmosPlayer") })
            AboutRow("开源许可证", "GPL-3.0")
            AboutRow("反馈问题", "发送邮件", onClick = { sendFeedback(ctx, info.versionName) })
            AboutRow("检查更新", "当前为最新开发版", onClick = {
                Toast.makeText(ctx, "暂未接入更新通道（开发版）", Toast.LENGTH_SHORT).show()
            })

            AboutDivider()
            Text("第三方开源组件", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp))
            LibRow("Media3 / ExoPlayer", "Apache-2.0", "媒体播放引擎")
            LibRow("Jetpack Compose / Material 3", "Apache-2.0", "UI 框架")
            LibRow("Coil", "Apache-2.0", "封面加载")
            LibRow("Haze", "Apache-2.0", "模糊背景")
            LibRow("Room / DataStore", "Apache-2.0", "数据存储")
            LibRow("Hilt", "Apache-2.0", "依赖注入")
            LibRow("juniversalchardet", "MPL-1.1", "歌词编码探测")

            AboutDivider()
            Text("版本历史", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp))
            Text(
                "0.12  扫描目录管理 / 沉浸封面模式 / 杜比能力检测页 / 关于页\n" +
                    "0.11  逐字歌词性能日志修复\n" +
                    "0.10  逐字卡拉OK歌词 + 平滑滚动\n" +
                    "0.9   格式徽章 / 格式信息面板 / 歌词优化\n" +
                    "0.8   封面链路修复\n" +
                    "0.7   文件夹页 / 曲库补全\n" +
                    "0.6   全景声页 / 设置 / 动态封面",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.6f),
                modifier = Modifier.fillMaxWidth(),
            )

            AboutDivider()
            Text("© 2025-2026 atmospan · 仅供个人学习交流使用", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.45f))
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AboutDivider() {
    HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = MaterialTheme.colorScheme.onSurface.copy(0.08f))
}

@Composable
private fun AboutRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.6f), modifier = Modifier.weight(1f))
        if (onClick != null) {
            androidx.compose.material3.TextButton(onClick = onClick) { Text(value, style = MaterialTheme.typography.bodySmall) }
        } else {
            Text(value, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun LibRow(name: String, license: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
        }
        Text(license, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
    }
}
