package com.atmosplayer

import android.app.Application
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.atmosplayer.artwork.buildImageLoader
import dagger.hilt.android.HiltAndroidApp
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@HiltAndroidApp
class AtmosApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        com.atmosplayer.util.Trace.init(this)
        com.atmosplayer.util.Trace.log("App.onCreate")
        installCrashHandler()
    }

    override fun newImageLoader(): ImageLoader = buildImageLoader(this)

    /** 全局崩溃捕获：堆栈写入 Android/data/com.atmosplayer/files/crash.txt，便于回传排查 */
    private fun installCrashHandler() {
        val default = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val dir = getExternalFilesDir(null) ?: filesDir
                dir.mkdirs()
                java.io.File(dir, "crash.txt").appendText(
                    "\n===== $stamp =====\nthread=${t.name}\n$sw\n"
                )
                Log.e("AtmosPlayer", "Crash saved to ${dir.absolutePath}/crash.txt", e)
            }
            default?.uncaughtException(t, e) ?: android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
