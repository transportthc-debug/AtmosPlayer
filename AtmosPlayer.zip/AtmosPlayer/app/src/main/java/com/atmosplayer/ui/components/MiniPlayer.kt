package com.atmosplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosplayer.playback.PlayerManager
import dev.chrisbanes.haze.hazeEffect

/** 底部迷你播放条（液态玻璃：Haze 真背景模糊 + 渐变 tint + 高光描边）。封面从音频文件内嵌提取。 */
@Composable
fun MiniPlayer(
    state: PlayerManager.UiState,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
    hazeState: dev.chrisbanes.haze.HazeState? = null
) {
    if (state.currentTrackId == null) return
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .clip(shape)
            .then(
                if (hazeState != null) Modifier.hazeEffect(
                    state = hazeState,
                    style = dev.chrisbanes.haze.HazeStyle(
                        backgroundColor = Color(0x990B0B10),
                        tint = dev.chrisbanes.haze.HazeTint(Color.Black.copy(alpha = 0.45f)),
                        blurRadius = 40.dp,
                        noiseFactor = 0.04f
                    )
                ) else Modifier
            )
            .glassSurface(shape = shape, tint = Color.White.copy(alpha = 0.13f), borderAlpha = 0.42f)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Artwork(
                artworkKey = state.artworkKey,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(44.dp),
                tag = "miniplayer"
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(state.title, color = Color.White, fontSize = 15.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(state.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onToggle) {
                Icon(
                    if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = null, tint = Color.White
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, contentDescription = null, tint = Color.White)
            }
        }
        val progress = if (state.durationMs > 0)
            (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .height(2.dp),
            color = Color.White,
            trackColor = Color.White.copy(alpha = 0.2f)
        )
    }
}
