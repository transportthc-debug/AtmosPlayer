package com.atmosplayer.util

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 崩溃定位面包屑：每个关键步骤立即追加一行到 trace.txt（同步写入，保证崩溃前的最后一行一定落盘）。
 * 文件位置：Android/data/com.atmosplayer/files/trace.txt
 */
object Trace {
    @Volatile private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) {
        if (file == null) {
            val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            dir.mkdirs()
            file = File(dir, "trace.txt")
            runCatching { file?.writeText("=== trace start ${fmt.format(Date())} ===\n") }
        }
    }

    fun log(step: String) {
        Log.i("AtmosTrace", step)
        runCatching {
            file?.appendText("${fmt.format(Date())}  $step\n")
        }
    }

    fun error(step: String, e: Throwable) {
        Log.e("AtmosTrace", "$step : ${e.javaClass.simpleName}: ${e.message}", e)
        runCatching {
            file?.appendText("${fmt.format(Date())}  ERROR $step : ${e.javaClass.simpleName}: ${e.message}\n${e.stackTraceToString()}\n")
        }
    }
}
