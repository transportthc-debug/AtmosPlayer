package com.atmosplayer.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.library.LibraryRepository
import com.atmosplayer.playback.PlayerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@UnstableApi
@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repo: LibraryRepository,
    val playerManager: PlayerManager,
    private val lyricsDao: com.atmosplayer.data.db.LyricsDao,
    private val settings: com.atmosplayer.data.SettingsRepository
) : ViewModel() {

    /** 清空歌词缓存（升级歌词引擎后调用，避免旧缓存挡住新解析路径） */
    suspend fun clearLyricsCache() = lyricsDao.clearCache()

    // ---- 扫描目录管理 ----
    val scanMode = settings.scanMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val scanWhitelist = settings.scanWhitelist.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val scanBlacklist = settings.scanBlacklist.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun setScanMode(mode: Int) = viewModelScope.launch { settings.setScanMode(mode) }
    fun addWhitelist(path: String) = viewModelScope.launch { settings.addWhitelist(path) }
    fun removeWhitelist(path: String) = viewModelScope.launch { settings.removeWhitelist(path) }
    fun addBlacklist(path: String) = viewModelScope.launch { settings.addBlacklist(path) }
    fun removeBlacklist(path: String) = viewModelScope.launch { settings.removeBlacklist(path) }

    /** 只扫描此文件夹：切白名单模式且白名单=该文件夹 */
    fun scanOnlyThisFolder(folder: String) = viewModelScope.launch {
        settings.setWhitelist(setOf(folder))
        settings.setScanMode(1)
        scan()
    }

    /** 屏蔽此文件夹：加黑名单（白名单模式下排除子目录同理），并重扫 */
    fun blockFolder(folder: String) = viewModelScope.launch {
        settings.addBlacklist(folder)
        scan()
    }

    /** 从曲库移除该文件夹歌曲（不入黑名单） */
    fun removeFolderFromLibrary(folder: String) = viewModelScope.launch {
        repo.removeFolder(folder)
    }

    val tracks = repo.tracks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val favorites = repo.favorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recent = repo.recent.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val atmos = repo.atmosTracks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<TrackEntity>> = _query
        .flatMapLatest { if (it.isBlank()) repo.tracks else repo.search(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _scanning = MutableStateFlow(false)
    val scanning = _scanning.asStateFlow()
    private val _scanCount = MutableStateFlow(-1)
    val scanCount = _scanCount.asStateFlow()

    init { playerManager.connect() }

    fun setQuery(q: String) { _query.value = q }

    fun scan() {
        if (_scanning.value) return
        viewModelScope.launch {
            _scanning.value = true
            _scanCount.value = runCatching { repo.scan() }.getOrElse {
                android.util.Log.e("AtmosPlayer", "scan failed", it)
                -1
            }
            _scanning.value = false
        }
    }

    fun play(list: List<TrackEntity>, index: Int) = playerManager.playQueue(list, index)
    fun toggleFavorite(t: TrackEntity) =
        viewModelScope.launch { repo.toggleFavorite(t.id, !t.isFavorite) }
}
