package com.atmosplayer.lyrics

import com.atmosplayer.data.db.LyricsCacheEntity
import com.atmosplayer.data.db.LyricsDao
import com.atmosplayer.data.db.LyricOffsetEntity
import com.atmosplayer.data.db.TrackEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 歌词加载优先级（增强逐字 LRC 优先于 TTML）：
 * 1. 内嵌歌词：m4a ©lyr atom；flac VorbisComment LYRICS；mp3 ID3v2 USLT
 * 2. 同目录同名 .lrc（普通/增强逐字，自动识别编码 UTF-8/GBK/GB18030/BIG5）
 * 3. 同目录同名 .ttml
 * 4. 无歌词
 *
 * 缓存策略：缓存"有歌词"的结果；"无歌词"的缓存只在确认当前仍无外部歌词文件时才生效，
 * 避免用户后来用 Lyrico 等工具补了歌词却被旧缓存挡住。
 */
@Singleton
class LyricsRepository @Inject constructor(
    private val lyricsDao: LyricsDao
) {

    suspend fun load(track: TrackEntity): Lyrics = withContext(Dispatchers.IO) {
        val lrc = sidecar(track.path, "lrc")
        val ttml = sidecar(track.path, "ttml")
        com.atmosplayer.util.Trace.log("lyrics.load: ${track.title} | lrc=${lrc?.name} ttml=${ttml?.name}")

        lyricsDao.cache(track.id)?.let { c ->
            if (c.source == "NONE") {
                // 旧缓存说没歌词：只有当现在确认也没有任何外部歌词文件时才采信
                if (lrc == null && ttml == null) {
                    // 内嵌仍可能出现（重新写入过标签），低概率，做一次快速探测
                    val emb = readEmbedded(track.path) ?: return@withContext Lyrics(emptyList(), LyricSource.NONE, false)
                    val lyrics = parseAuto(emb, LyricSource.EMBEDDED)
                    cache(track.id, emb, LyricSource.EMBEDDED, lyrics.isWordTimed)
                    return@withContext lyrics
                }
                // 有外部文件 → 穿透缓存继续向下执行
            } else {
                c.rawContent?.let { return@withContext parseAuto(it, LyricSource.valueOf(c.source)) }
            }
        }

        // 1. 内嵌
        readEmbedded(track.path)?.let { raw ->
            com.atmosplayer.util.Trace.log("lyrics.embedded found: ${raw.length} chars")
            val lyrics = parseAuto(raw, LyricSource.EMBEDDED)
            com.atmosplayer.util.Trace.log("lyrics.parsed: ${lyrics.lines.size} lines wordTimed=${lyrics.isWordTimed}")
            cache(track.id, raw, LyricSource.EMBEDDED, lyrics.isWordTimed)
            return@withContext lyrics
        }
        // 2. 同名 LRC（编码自动识别，解决 GBK 乱码）
        if (lrc != null) {
            val raw = TextDecoder.readFile(lrc)
            if (!raw.isNullOrBlank()) {
                val lyrics = EnhancedLrcParser.parse(raw).copy(source = LyricSource.LRC_FILE)
                com.atmosplayer.util.Trace.log("lyrics.lrc parsed: ${lyrics.lines.size} lines wordTimed=${lyrics.isWordTimed}")
                cache(track.id, raw, LyricSource.LRC_FILE, lyrics.isWordTimed)
                return@withContext lyrics
            }
        }
        // 3. 同名 TTML
        if (ttml != null) {
            val raw = TextDecoder.readFile(ttml)
            if (!raw.isNullOrBlank()) {
                val lyrics = TtmlParser.parse(raw).copy(source = LyricSource.TTML_FILE)
                cache(track.id, raw, LyricSource.TTML_FILE, lyrics.isWordTimed)
                return@withContext lyrics
            }
        }
        com.atmosplayer.util.Trace.log("lyrics: NONE for ${track.title}")
        cache(track.id, null, LyricSource.NONE, false)
        Lyrics(emptyList(), LyricSource.NONE, false)
    }

    /** 内嵌歌词：按容器分发 */
    private fun readEmbedded(path: String): String? {
        val lower = path.lowercase()
        return when {
            lower.endsWith(".m4a") || lower.endsWith(".mp4") ->
                Mp4AtomReader.read(path).lyricsRaw?.takeIf { it.isNotBlank() }
            else -> EmbeddedLyricsReader.read(path)
        }
    }

    private fun sidecar(trackPath: String, ext: String): File? {
        val f = File(trackPath)
        val dir = f.parentFile ?: return null
        val base = f.nameWithoutExtension
        return listOf("$base.$ext", "$base.${ext.uppercase()}")
            .map { File(dir, it) }
            .firstOrNull { it.exists() && it.length() > 0 }
    }

    private fun parseAuto(raw: String, source: LyricSource): Lyrics = when {
        TtmlParser.canParse(raw) -> TtmlParser.parse(raw).copy(source = source)
        EnhancedLrcParser.canParse(raw) -> EnhancedLrcParser.parse(raw).copy(source = source)
        else -> Lyrics(
            lines = raw.lineSequence().filter { it.isNotBlank() }
                .mapIndexed { i, l -> LyricLine(i * 4000L, (i + 1) * 4000L, listOf(LyricWord(l, 0, 0))) }
                .toList(),
            source = source, isWordTimed = false
        )
    }

    private suspend fun cache(trackId: String, raw: String?, source: LyricSource, wordTimed: Boolean) {
        lyricsDao.saveCache(LyricsCacheEntity(trackId, source.name, raw, wordTimed))
    }

    suspend fun offset(trackId: String): Long = lyricsDao.offset(trackId)?.offsetMs ?: 0L
    suspend fun saveOffset(trackId: String, offsetMs: Long) =
        lyricsDao.saveOffset(LyricOffsetEntity(trackId, offsetMs))
}
