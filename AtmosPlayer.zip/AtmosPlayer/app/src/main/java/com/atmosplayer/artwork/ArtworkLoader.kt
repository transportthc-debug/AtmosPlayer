package com.atmosplayer.artwork

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import coil.size.Size
import java.io.File
import java.io.FileInputStream

/**
 * 封面加载链（参考成熟本地播放器的通用做法）：
 * 1. 内嵌封面原图：MediaMetadataRetriever.getEmbeddedPicture()
 *    支持 m4a(covr atom) / flac(Picture block) / mp3(APIC) / wav(id3)
 * 2. 同目录 cover/folder/front/album 图片
 * 3. MediaStore 系统相册封面（锁屏/通知栏同源）
 * 4. 全部失败 → 生成默认渐变封面 Bitmap（不再让 Coil 抛 "Unable to create a fetcher"）
 *
 * 清晰度策略：Coil 会传入目标尺寸 options.size。
 * - 列表缩略图：按目标尺寸 inSampleSize 采样，省内存
 * - 播放页大图：UI 请求 Size.ORIGINAL，解码原图（上限 2048px 防 OOM）
 */
class EmbeddedArtFetcher(
    private val path: String,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        com.atmosplayer.util.Trace.log("coil.fetch[$path] targetSize=${options.size}")
        val loaded = ArtworkBytes.load(path, options.context)
        if (loaded == null) {
            // 无封面：不返回 null（会让 Coil 抛异常），直接给默认封面
            com.atmosplayer.util.Trace.log("artwork[$path] source=NONE -> default")
            return DrawableResult(
                drawable = defaultCoverBitmap().toDrawable(options.context.resources),
                isSampled = false,
                dataSource = DataSource.MEMORY
            )
        }
        val (bytes, source) = loaded
        val bmp = try {
            decodeSmart(bytes)
        } catch (e: Throwable) {
            com.atmosplayer.util.Trace.error("artwork[$path] decode THREW bytes=${bytes.size} source=$source", e)
            null
        }
        if (bmp == null) {
            com.atmosplayer.util.Trace.log("artwork[$path] decode FAILED bytes=${bytes.size} source=$source -> default")
            return DrawableResult(
                drawable = defaultCoverBitmap().toDrawable(options.context.resources),
                isSampled = false,
                dataSource = DataSource.MEMORY
            )
        }
        com.atmosplayer.util.Trace.log("artwork[$path] decode OK ${bmp.width}x${bmp.height} source=$source")
        return DrawableResult(
            drawable = bmp.toDrawable(options.context.resources),
            isSampled = true,
            dataSource = DataSource.DISK
        )
    }

    /** 采样解码：ORIGINAL（播放页）上限 2048px，其余（列表）约 512px */
    private fun decodeSmart(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // 播放页(Size.ORIGINAL)：上限 2048px——真机日志显示 Lyrico 嵌入的封面可达 8000x8000，
        // 全尺寸解码需 ~256MB 直接 OOM 导致封面显示失败；2048px 对 1440p 屏已是无损观感。
        // 列表/迷你条：采样到约 512px。
        val maxDim = if (options.size == Size.ORIGINAL) 2048 else 512
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) }.getOrNull()
    }

    class Factory : Fetcher.Factory<String> {
        override fun create(data: String, options: Options, imageLoader: ImageLoader): Fetcher? =
            if (data.startsWith("art://")) EmbeddedArtFetcher(data.removePrefix("art://"), options)
            else null
    }

    /**
     * Coil 2.x 内置 StringMapper 会先把 String model 映射成 Uri，之后只查找
     * Fetcher.Factory<Uri> —— Factory<String> 会被旁路。必须注册 Uri 工厂。
     */
    class UriFactory : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? {
            if (data.scheme != "art") return null
            val path = data.path ?: return null
            return EmbeddedArtFetcher(path, options)
        }
    }
}

/** 与 DefaultCover 一致的紫黑渐变默认封面（无封面文件时使用） */
private var cachedDefaultCover: Bitmap? = null

@Synchronized
private fun defaultCoverBitmap(): Bitmap {
    cachedDefaultCover?.let { return it }
    val size = 512
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, 0f, size.toFloat(), size.toFloat(),
            0xFF3D2A6E.toInt(), 0xFF1A1030.toInt(), Shader.TileMode.CLAMP
        )
    }
    canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)
    cachedDefaultCover = bmp
    return bmp
}

fun buildImageLoader(context: Context): ImageLoader =
    ImageLoader.Builder(context)
        .components {
            add(EmbeddedArtFetcher.UriFactory())
            add(EmbeddedArtFetcher.Factory())
        }
        .crossfade(true)
        .build()

/**
 * 共享封面字节提取（UI / Palette / 调试日志统一入口）：
 * 1. MediaMetadataRetriever 内嵌封面（路径失败时 FileDescriptor 兜底——巨型 WAV 路径解析可能失败）
 * 2. m4a covr atom（TagLib/Lyrico 写入位置，AC-4 容器 retriever 失败时的兜底）
 * 3. 同目录 cover/folder/front/album/artwork 图片（jpg/jpeg/png/webp，大小写不敏感）
 * 4. MediaStore 系统相册封面（与锁屏/通知栏同一来源）
 */
object ArtworkBytes {

    private val coverBaseNames = listOf("cover", "folder", "front", "album", "artwork")
    private val coverExts = listOf("jpg", "jpeg", "png", "webp")

    /** @return bytes + 来源标签 */
    fun load(path: String, ctx: Context? = null): Pair<ByteArray, String>? {
        // 1. 系统 retriever（路径 → FD 双通道）
        val mmr = MediaMetadataRetriever()
        var setOk = false
        try {
            mmr.setDataSource(path); setOk = true
        } catch (e: Throwable) {
            runCatching {
                FileInputStream(path).use { fis -> mmr.setDataSource(fis.fd) }
                setOk = true
            }
        }
        if (setOk) {
            try {
                mmr.embeddedPicture?.let {
                    com.atmosplayer.util.Trace.log("artwork[$path] source=embedded-retriever bytes=${it.size}")
                    return it to "embedded"
                }
                com.atmosplayer.util.Trace.log("artwork[$path] retriever: embeddedPicture=null")
            } catch (e: Throwable) {
                com.atmosplayer.util.Trace.log("artwork[$path] retriever read failed: ${e.message}")
            }
        } else {
            // 单行日志，不刷堆栈（不影响列表滚动）
            com.atmosplayer.util.Trace.log("artwork[$path] retriever: setDataSource failed (path+fd), skip")
        }
        runCatching { mmr.release() }

        // 2. m4a covr atom
        if (path.endsWith(".m4a", true) || path.endsWith(".mp4", true)) {
            val covr = com.atmosplayer.lyrics.Mp4AtomReader.read(path).coverBytes
            if (covr != null) {
                com.atmosplayer.util.Trace.log("artwork[$path] source=embedded-covr bytes=${covr.size}")
                return covr to "embedded"
            }
            com.atmosplayer.util.Trace.log("artwork[$path] covr: not found")
        }

        // 3. 同目录封面文件（大小写不敏感，jpg/jpeg/png/webp）
        findFolderCover(File(path).parentFile)?.let { f ->
            val bytes = runCatching { f.readBytes() }.getOrNull()
            if (bytes != null) {
                com.atmosplayer.util.Trace.log("artwork[$path] source=folder bytes=${bytes.size} file=${f.name}")
                return bytes to "folder"
            }
        }

        // 4. MediaStore 系统相册封面（锁屏/通知栏同源）
        if (ctx != null) {
            val art = loadMediaStoreArt(ctx, path)
            if (art != null) {
                com.atmosplayer.util.Trace.log("artwork[$path] source=mediastore bytes=${art.size}")
                return art to "mediastore"
            }
        }

        com.atmosplayer.util.Trace.log("artwork[$path] source=NONE")
        return null
    }

    /** 音频信息页用：只探测封面来源标签，不写日志、不返回字节 */
    fun peekSource(path: String): String {
        val mmr = MediaMetadataRetriever()
        var setOk = false
        try { mmr.setDataSource(path); setOk = true } catch (_: Throwable) {
            runCatching { FileInputStream(path).use { mmr.setDataSource(it.fd) }; setOk = true }
        }
        if (setOk) {
            val has = runCatching { mmr.embeddedPicture != null }.getOrDefault(false)
            runCatching { mmr.release() }
            if (has) return "内嵌封面"
        } else runCatching { mmr.release() }
        if (path.endsWith(".m4a", true) || path.endsWith(".mp4", true)) {
            if (runCatching { com.atmosplayer.lyrics.Mp4AtomReader.read(path).coverBytes != null }
                    .getOrDefault(false)) return "内嵌封面 (covr atom)"
        }
        findFolderCover(File(path).parentFile)?.let { return "目录封面 (${it.name})" }
        return "无（默认封面）"
    }

    /** 同目录封面查找：cover/folder/front/album/artwork × jpg/jpeg/png/webp，大小写不敏感 */
    private fun findFolderCover(dir: File?): File? {
        if (dir == null || !dir.isDirectory) return null
        val files = dir.listFiles() ?: return null
        return files.firstOrNull { f ->
            f.isFile &&
            f.nameWithoutExtension.lowercase() in coverBaseNames &&
            f.extension.lowercase() in coverExts
        }
    }

    /** 通过 MediaStore albumId 取系统相册封面 */
    private fun loadMediaStoreArt(ctx: Context, path: String): ByteArray? = runCatching {
        val proj = arrayOf(android.provider.MediaStore.Audio.Media.ALBUM_ID)
        ctx.contentResolver.query(
            android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
            android.provider.MediaStore.Audio.Media.DATA + "=?", arrayOf(path), null
        )?.use { c ->
            if (!c.moveToFirst()) return null
            val albumId = c.getLong(0)
            val uri = android.content.ContentUris.withAppendedId(
                android.net.Uri.parse("content://media/external/audio/albumart"), albumId)
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        }
    }.getOrNull()
}
