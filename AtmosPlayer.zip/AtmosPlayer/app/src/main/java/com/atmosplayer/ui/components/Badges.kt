package com.atmosplayer.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.playback.DolbyCapabilities

/**
 * 格式徽章系统（精致小芯片）：
 * - DOLBY ATMOS：杜比全景声（audio/ac4、eac3-joc、Immersive 元数据）
 * - DOLBY AUDIO：杜比数字（ac3/eac3 非 Atmos）
 * - HI-RES：金标——无损编码且采样率 > 48kHz（或位深 > 16bit）
 * - LOSSLESS：无损编码（FLAC/ALAC/WAV/AIFF/DSD）
 */
object QualityBadges {

    enum class Kind { DOLBY_ATMOS, DOLBY_AUDIO, HI_RES, LOSSLESS }

    private val losslessExt = setOf("flac", "alac", "wav", "aiff", "aif", "dsd", "dsf", "dff", "ape")
    private val losslessMime = setOf(
        "audio/flac", "audio/x-flac", "audio/alac", "audio/wav", "audio/x-wav",
        "audio/aiff", "audio/x-aiff", "audio/raw", "audio/vnd.dts.hd"
    )

    fun isLossless(mime: String?, path: String?): Boolean {
        val ext = path?.substringAfterLast('.', "")?.lowercase() ?: ""
        return (mime?.lowercase() in losslessMime) || ext in losslessExt ||
                (ext == "m4a" && mime?.contains("alac", true) == true)
    }

    fun isHiRes(mime: String?, path: String?, sampleRate: Int, bitDepth: Int = 0): Boolean =
        isLossless(mime, path) && (sampleRate > 48000 || bitDepth > 16)

    fun kinds(mime: String?, path: String?, sampleRate: Int, bitDepth: Int = 0): List<Kind> =
        buildList {
            when {
                DolbyCapabilities.isAtmosMime(mime) -> add(Kind.DOLBY_ATMOS)
                DolbyCapabilities.isDolbyMime(mime) -> add(Kind.DOLBY_AUDIO)
            }
            if (isHiRes(mime, path, sampleRate, bitDepth)) add(Kind.HI_RES)
            else if (isLossless(mime, path)) add(Kind.LOSSLESS)
        }

    fun forTrack(t: TrackEntity): List<Kind> =
        kinds(t.codecMime, t.path, t.sampleRate)
}

@Composable
fun QualityBadgeRow(kinds: List<QualityBadges.Kind>, compact: Boolean = false) {
    if (kinds.isEmpty()) return
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        kinds.forEach { QualityBadge(it, compact) }
    }
}

@Composable
fun QualityBadge(kind: QualityBadges.Kind, compact: Boolean = false) {
    val (label, fg, borderBrush) = when (kind) {
        QualityBadges.Kind.DOLBY_ATMOS -> Triple(
            "DOLBY ATMOS", Color(0xFFEDE7FF),
            Brush.horizontalGradient(listOf(Color(0xFF7C5CFF), Color(0xFFB39DDB)))
        )
        QualityBadges.Kind.DOLBY_AUDIO -> Triple(
            "DOLBY AUDIO", Color.White.copy(alpha = 0.85f),
            Brush.horizontalGradient(listOf(Color.White.copy(0.5f), Color.White.copy(0.3f)))
        )
        QualityBadges.Kind.HI_RES -> Triple(
            "HI-RES", Color(0xFFFFD980),
            Brush.horizontalGradient(listOf(Color(0xFFFFC94D), Color(0xFFFFE9A8)))
        )
        QualityBadges.Kind.LOSSLESS -> Triple(
            "LOSSLESS", Color(0xFF9EE8FF),
            Brush.horizontalGradient(listOf(Color(0xFF4FC3F7).copy(0.8f), Color(0xFF9EE8FF).copy(0.6f)))
        )
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(4.dp))
            .border(0.6.dp, borderBrush, RoundedCornerShape(4.dp))
            .padding(
                horizontal = if (compact) 3.dp else 5.dp,
                vertical = if (compact) 0.5.dp else 1.5.dp
            )
    ) {
        Text(
            label,
            style = TextStyle(
                color = fg,
                fontSize = if (compact) 6.5.sp else 8.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        )
    }
}
