package com.atmosplayer.ui.player

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosplayer.lyrics.LyricLine
import com.atmosplayer.lyrics.LyricSource
import com.atmosplayer.lyrics.Lyrics
import kotlinx.coroutines.isActive

/**
 * Apple Music / QQ音乐 级逐字歌词系统：
 *
 * 同步：播放器 200ms tick 只作锚点，当前行内部用 withFrameNanos 按
 *       单调时钟逐帧外推播放位置 —— 扫光 60fps 丝滑，而全局重组为零。
 * 滚动：跨行才触发 animateScrollToItem（spring 物理插值），
 *       目标行定位到视口 40% 高度处（视觉中心偏上）；
 *       用户手动滑动时完全暂停自动滚动，停手 3s 后平滑回归当前行。
 * 渲染：当前行 / 非当前行分离 composable；positionMs 只流入当前行；
 *       非当前行在进度 tick 时零重组；LazyColumn 稳定 key = startMs。
 * 高亮：逐词按时间窗插值渐变 + 当前词发光（SpanStyle shadow 辉光）。
 * 埋点：LyricsPerf 每 10s 输出 tick 频率/索引更新/重组/滚动/jank 统计。
 */
@Composable
fun LyricsView(
    lyrics: Lyrics,
    positionMs: Long,
    isPlaying: Boolean,
    offsetMs: Long,
    showTranslation: Boolean,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (lyrics.source == LyricSource.NONE || lyrics.lines.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("暂无歌词", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
        }
        return
    }

    val listState = rememberLazyListState()
    val lines = lyrics.lines
    val density = LocalDensity.current

    // ---- 埋点：tick 频率 ----
    var lastTick by remember { mutableLongStateOf(-1L) }
    if (positionMs != lastTick) {
        lastTick = positionMs
        LyricsPerf.tick()
    }
    // 切歌重置 + 每 10s 汇总
    LaunchedEffect(lyrics) {
        LyricsPerf.reset()
        while (isActive) {
            kotlinx.coroutines.delay(10_000)
            LyricsPerf.flush(10)
        }
    }

    // ---- 行索引：二分查找，跨行才变化（埋点计数）----
    val effectivePos = positionMs + offsetMs
    val currentIndex = lyrics.lineIndexAt(effectivePos)
    var lastIndex by remember { mutableIntStateOf(-1) }
    if (currentIndex != lastIndex) {
        lastIndex = currentIndex
        LyricsPerf.lineIndexChanged()
    }

    // ---- 手动滑动保护：用户触摸滚动期间完全暂停自动滚动 ----
    var lastManualScrollNanos by remember { mutableLongStateOf(0L) }
    val userScrolling = listState.isScrollInProgress
    LaunchedEffect(userScrolling) {
        if (userScrolling) {
            LyricsPerf.manualInterrupt()
            lastManualScrollNanos = System.nanoTime()
            // 滑动期间持续刷新时间戳，松手后 3s 才允许回归
            while (listState.isScrollInProgress) {
                lastManualScrollNanos = System.nanoTime()
                kotlinx.coroutines.delay(200)
            }
        }
    }

    // ---- 切歌瞬移：不与上一首的滚动动画纠缠 ----
    LaunchedEffect(lyrics) {
        val idx = lyrics.lineIndexAt(effectivePos).coerceAtLeast(0)
        if (idx < lines.size) listState.scrollToItem(idx)
    }

    // ---- 自动滚动：仅跨行触发，spring 平滑定位到视觉中心偏上 ----
    LaunchedEffect(currentIndex) {
        if (currentIndex < 0) return@LaunchedEffect
        if (listState.isScrollInProgress) return@LaunchedEffect
        val idleMs = (System.nanoTime() - lastManualScrollNanos) / 1_000_000
        if (lastManualScrollNanos != 0L && idleMs < 3_000) return@LaunchedEffect

        val viewportH = listState.layoutInfo.viewportSize.height
        val estLineH = with(density) { (if (showTranslation) 88.dp else 62.dp).toPx() }
        val offset = -(viewportH * 0.40f - estLineH / 2).toInt()
        val t0 = System.nanoTime()
        listState.animateScrollToItem(currentIndex, scrollOffset = offset)
        LyricsPerf.autoScroll((System.nanoTime() - t0) / 1_000_000)
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 200.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        items(
            count = lines.size,
            key = { i -> lines[i].startMs },          // 稳定 key：行复用，不重排
            contentType = { "lyric" }                 // 统一 contentType 提升回收效率
        ) { i ->
            val line = lines[i]
            if (i == currentIndex) {
                CurrentLyricLine(
                    line = line,
                    anchorPosMs = effectivePos,
                    isPlaying = isPlaying,
                    showTranslation = showTranslation,
                    onSeek = onSeek
                )
            } else {
                PassiveLyricLine(
                    line = line,
                    played = i < currentIndex,
                    showTranslation = showTranslation,
                    onClick = { onSeek(line.startMs) }
                )
            }
        }
    }
}

/**
 * 当前行：独立 composable，帧驱动局部更新。
 * 以播放器 tick 为锚点 + 单调时钟外推，扫光动画每帧刷新但只重组这一行。
 */
@Composable
private fun CurrentLyricLine(
    line: LyricLine,
    anchorPosMs: Long,
    isPlaying: Boolean,
    showTranslation: Boolean,
    onSeek: (Long) -> Unit
) {
    LyricsPerf.currentLineRecomposed()

    // spring 放大（只在进入/离开当前行时跑一次，不随帧动）
    val scale by animateFloatAsState(
        targetValue = 1.08f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "lyricScale"
    )

    // ---- 帧驱动位置外推：tick 锚点 + 单调时钟 ----
    val framePos = remember { mutableLongStateOf(anchorPosMs) }
    val latestAnchor by rememberUpdatedState(anchorPosMs)
    LaunchedEffect(isPlaying) {
        if (!isPlaying) {
            framePos.longValue = latestAnchor
            return@LaunchedEffect
        }
        var base = latestAnchor
        var baseNano = System.nanoTime()
        var lastFrameNano = baseNano
        while (isActive) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (latestAnchor != base) {   // 新 tick 到达：重新锚定（seek/漂移自校正）
                    base = latestAnchor
                    baseNano = now
                }
                framePos.longValue = base + (now - baseNano) / 1_000_000
                LyricsPerf.frame((now - lastFrameNano) / 1_000_000)
                lastFrameNano = now
            }
        }
    }
    // 暂停时直接跟随锚点
    if (!isPlaying) framePos.longValue = anchorPosMs

    val pos = framePos.longValue

    // ---- 当前词索引（埋点）----
    if (line.isWordTimed) {
        val wIdx = line.words.indexOfLast { pos >= it.startMs }
        var lastW by remember { mutableIntStateOf(-1) }
        if (wIdx != lastW) {
            lastW = wIdx
            LyricsPerf.wordIndexChanged()
        }
    }

    val style = TextStyle(
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = 32.sp
    )
    Column(
        Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = { onSeek(line.startMs) }
            )
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
    ) {
        if (line.isWordTimed) {
            Text(text = karaokeText(line, pos), style = style)
        } else {
            Text(text = line.text, style = style, color = Color.White)
        }
        if (showTranslation && !line.translation.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = line.translation!!,
                fontSize = 16.sp,
                color = Color.White.copy(alpha = 0.75f)
            )
        }
        if (showTranslation && !line.romanization.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = line.romanization!!,
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.55f)
            )
        }
    }
}

/** 非当前行：完全不接收 positionMs，进度 tick 时零重组 */
@Composable
private fun PassiveLyricLine(
    line: LyricLine,
    played: Boolean,
    showTranslation: Boolean,
    onClick: () -> Unit
) {
    val style = TextStyle(
        fontSize = 20.sp,
        fontWeight = FontWeight.Medium,
        lineHeight = 28.sp
    )
    // 已唱过的行略亮于未唱行，层次更接近 Apple Music
    val color = Color.White.copy(alpha = if (played) 0.55f else 0.38f)
    Column(
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClick
        )
    ) {
        Text(text = line.text, style = style, color = color)
        if (showTranslation && !line.translation.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = line.translation!!,
                fontSize = 14.sp,
                color = Color.White.copy(alpha = if (played) 0.45f else 0.32f)
            )
        }
        if (showTranslation && !line.romanization.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = line.romanization!!,
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.30f)
            )
        }
    }
}

/**
 * 逐字扫光渲染：每个词按自己的时间窗插值渐变着色；
 * 正在唱的词附加辉光（shadow 光晕），已唱纯白，未唱 42% 白。
 */
private fun karaokeText(line: LyricLine, positionMs: Long): AnnotatedString =
    AnnotatedString.Builder().apply {
        line.words.forEach { w ->
            val frac = when {
                positionMs >= w.endMs -> 1f
                positionMs <= w.startMs -> 0f
                else -> (positionMs - w.startMs).toFloat() / (w.endMs - w.startMs).coerceAtLeast(1)
            }
            val singing = positionMs in w.startMs until w.endMs
            val c = lerpColor(Color.White.copy(alpha = 0.42f), Color.White, frac)
            pushStyle(
                SpanStyle(
                    color = c,
                    // 当前词发光：柔和白色光晕，扫光经过时如呼吸般点亮
                    shadow = if (singing) Shadow(
                        color = Color.White.copy(alpha = 0.85f),
                        offset = Offset.Zero,
                        blurRadius = 22f
                    ) else null
                )
            )
            append(w.text)
            pop()
        }
    }.toAnnotatedString()

private fun lerpColor(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = a.alpha + (b.alpha - a.alpha) * t
)
