package com.atmosplayer.lyrics

import java.io.RandomAccessFile
import java.nio.charset.Charset

/**
 * 轻量 MP4/M4A atom 遍历器：读取 moov/udta/meta/ilst 下的元数据。
 * 用途：©lyr 内嵌歌词、covr 封面、©nam/©ART/©alb 等标签。
 * 不依赖第三方库，支持 64bit atom 与 meta 的 4 字节版本头。
 */
object Mp4AtomReader {

    data class Mp4Tags(
        val title: String? = null,
        val artist: String? = null,
        val albumArtist: String? = null,
        val album: String? = null,
        val genre: String? = null,
        val year: String? = null,
        val copyright: String? = null,
        val encoder: String? = null,          // ©too 编码器/编码库
        val lyricsRaw: String? = null,        // ©lyr 原文
        val coverBytes: ByteArray? = null
    )

    fun read(path: String): Mp4Tags {
        var tags = Mp4Tags()
        try {
            RandomAccessFile(path, "r").use { f ->
                walk(f, 0, f.length(), intArrayOf(0), tags = { name, data ->
                    tags = when (name) {
                        "©lyr" -> tags.copy(lyricsRaw = decodeText(data))
                        "covr" -> tags.copy(coverBytes = data)
                        "©nam" -> tags.copy(title = decodeText(data))
                        "©ART" -> tags.copy(artist = decodeText(data))
                        "aART" -> tags.copy(albumArtist = decodeText(data))
                        "©alb" -> tags.copy(album = decodeText(data))
                        "©gen" -> tags.copy(genre = decodeText(data))
                        "©day" -> tags.copy(year = decodeText(data))
                        "cprt" -> tags.copy(copyright = decodeText(data))
                        "©too" -> tags.copy(encoder = decodeText(data))
                        else -> tags
                    }
                })
            }
        } catch (e: Exception) {
            // 读取失败不致命
        }
        return tags
    }

    private fun walk(
        f: RandomAccessFile,
        start: Long, end: Long,
        depth: IntArray,
        tags: (String, ByteArray) -> Unit
    ) {
        if (depth[0] > 8) return
        var pos = start
        while (pos + 8 <= end) {
            f.seek(pos)
            var size = f.readInt().toLong() and 0xFFFFFFFF
            val typeBytes = ByteArray(4)
            f.readFully(typeBytes)
            val type = String(typeBytes, Charsets.ISO_8859_1)
            var header = 8L
            if (size == 1L) {
                size = f.readLong()
                header = 16L
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < header || pos + size > end + 8) break

            when (type) {
                "moov", "udta", "ilst", "trak", "mdia", "minf", "stbl" -> {
                    depth[0]++
                    walk(f, pos + header, pos + size, depth, tags)
                    depth[0]--
                }
                "meta" -> {
                    depth[0]++
                    walk(f, pos + header + 4, pos + size, depth, tags) // 跳过版本/flags
                    depth[0]--
                }
                "©lyr", "covr", "©nam", "©ART", "aART", "©alb", "©gen" -> {
                    val payload = readDataAtom(f, pos + header, pos + size)
                    if (payload != null) tags(type, payload)
                }
            }
            pos += size
        }
    }

    /** ilst 子 atom 内部结构: [size 'data' ver/flags locale(4B) payload] */
    private fun readDataAtom(f: RandomAccessFile, start: Long, end: Long): ByteArray? {
        var pos = start
        while (pos + 8 <= end) {
            f.seek(pos)
            var size = f.readInt().toLong() and 0xFFFFFFFF
            val tb = ByteArray(4); f.readFully(tb)
            val type = String(tb, Charsets.ISO_8859_1)
            var header = 8L
            if (size == 1L) { size = f.readLong(); header = 16L }
            if (size < header) break
            if (type == "data") {
                val payloadStart = pos + header + 8 // 跳过 version/flags(4) + locale(4)
                val len = (pos + size - payloadStart).toInt()
                if (len in 1..(8 * 1024 * 1024)) {
                    val buf = ByteArray(len)
                    f.seek(payloadStart)
                    f.readFully(buf)
                    return buf
                }
                return null
            }
            pos += size
        }
        // 没有 data 子 atom，直接按原文读
        val len = (end - start).toInt()
        if (len in 1..(8 * 1024 * 1024)) {
            val buf = ByteArray(len)
            f.seek(start)
            f.readFully(buf)
            return buf
        }
        return null
    }

    /**
     * ©lyr/©nam 等文本 atom 解码：不再默认 UTF-8。
     * MP4 data atom 的 type flags 定义编码（1=UTF-8, 2=UTF-16BE），但国内工具写入不规范，
     * 统一交给 TextDecoder 做 BOM + chardet + GB18030 回退，并输出编码日志。
     */
    private fun decodeText(data: ByteArray): String {
        val (text, encoding) = TextDecoder.decodeWithInfo(data)
        com.atmosplayer.util.Trace.log(
            "mp4atom.decodeText bytes=${data.size} encoding=$encoding head=${text.take(20)}")
        return text
    }
}
