package com.atmosplayer.lyrics

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

/**
 * Apple Music 风格 TTML 歌词解析器（遵循 AMLL TTML 规范）。
 * 支持：itunes:timing=Word/Line、逐词 span、
 *       ttm:role="x-translation" 行内翻译、
 *       <head><iTunesMetadata><translations><text for="Lx"> Apple 侧轨翻译。
 */
object TtmlParser {

    fun canParse(raw: String): Boolean =
        raw.trimStart().let { it.startsWith("<?xml") || it.startsWith("<tt") || it.contains("<tt ") }

    fun parse(raw: String): Lyrics {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)

        val sideTranslations = mutableMapOf<String, String>()
        var inITunesMetadata = false
        var inTranslation = false
        var pendingTextFor: String? = null

        // 第一遍：收集 head 侧轨翻译
        parser.setInput(StringReader(raw))
        var event = parser.eventType
        var stop = false
        while (event != XmlPullParser.END_DOCUMENT && !stop) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "iTunesMetadata" -> inITunesMetadata = true
                    "translation" -> if (inITunesMetadata) inTranslation = true
                    "text" -> if (inTranslation) pendingTextFor = attr(parser, "for")
                    "body" -> stop = true
                }
                XmlPullParser.TEXT -> {
                    val k = pendingTextFor
                    if (inTranslation && k != null && !parser.text.isNullOrBlank()) {
                        sideTranslations[k] = (sideTranslations[k] ?: "") + parser.text.trim()
                    }
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "text" -> pendingTextFor = null
                    "translation" -> inTranslation = false
                    "iTunesMetadata" -> inITunesMetadata = false
                }
            }
            if (!stop) event = parser.next()
        }

        // 第二遍：解析 body 歌词
        parser.setInput(StringReader(raw))
        val lines = mutableListOf<LyricLine>()
        var inBody = false
        var curLineStart = 0L
        var curLineEnd = -1L
        var curLineKey: String? = null
        val curWords = mutableListOf<LyricWord>()
        var wordText: StringBuilder? = null
        var linePlain: StringBuilder? = null
        var isWordTimed = false

        event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "body" -> inBody = true
                    "p" -> if (inBody) {
                        curLineStart = parseTime(attr(parser, "begin")).coerceAtLeast(0)
                        curLineEnd = parseTime(attr(parser, "end"))
                        curLineKey = attrNS(parser, "http://music.apple.com/lyric-ttml-internal", "key")
                        curWords.clear()
                        linePlain = StringBuilder()
                    }
                    "span" -> if (inBody && linePlain != null) {
                        val role = attrNS(parser, "http://www.w3.org/ns/ttml#metadata", "role")
                        val b = parseTime(attr(parser, "begin"))
                        if (role == null && b >= 0) {
                            isWordTimed = true
                            wordText = StringBuilder()
                            curWords += LyricWord("", b, parseTime(attr(parser, "end")))
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (wordText != null) wordText!!.append(parser.text)
                    else linePlain?.append(parser.text)
                }
                XmlPullParser.END_TAG -> when (parser.name) {
                    "span" -> {
                        val wt = wordText
                        if (wt != null && curWords.isNotEmpty()) {
                            val last = curWords.removeAt(curWords.size - 1)
                            val e = if (last.endMs > last.startMs) last.endMs else last.startMs + 300
                            curWords += LyricWord(wt.toString(), last.startMs, e)
                        }
                        wordText = null
                    }
                    "p" -> if (inBody && linePlain != null) {
                        val lineEnd = if (curLineEnd > curLineStart) curLineEnd
                            else (curWords.lastOrNull()?.endMs ?: curLineStart + 4000)
                        val words = if (curWords.isNotEmpty()) curWords.toList()
                            else listOf(LyricWord(linePlain.toString().trim(), curLineStart, lineEnd))
                        if (words.any { it.text.isNotBlank() }) {
                            lines += LyricLine(
                                startMs = curLineStart, endMs = lineEnd,
                                words = words,
                                translation = curLineKey?.let { sideTranslations[it] }
                            )
                        }
                        linePlain = null
                    }
                    "body" -> inBody = false
                }
            }
            event = parser.next()
        }
        lines.sortBy { it.startMs }
        return Lyrics(lines, LyricSource.TTML_FILE, isWordTimed)
    }

    private fun attr(p: XmlPullParser, name: String): String? = p.getAttributeValue(null, name)
    private fun attrNS(p: XmlPullParser, ns: String, name: String): String? =
        p.getAttributeValue(ns, name) ?: p.getAttributeValue(null, name.split(":").last())

    /** 支持 "45.404" / "45.404s" / "00:45.404" / "01:23:45.404" */
    fun parseTime(s: String?): Long {
        if (s == null) return -1
        val t = s.trim().removeSuffix("s")
        return try {
            when {
                t.count { it == ':' } == 2 -> {
                    val (h, m, sec) = t.split(":")
                    (h.toLong() * 3600 + m.toLong() * 60) * 1000 + (sec.toDouble() * 1000).toLong()
                }
                t.contains(':') -> {
                    val (m, sec) = t.split(":")
                    m.toLong() * 60_000 + (sec.toDouble() * 1000).toLong()
                }
                else -> (t.toDouble() * 1000).toLong()
            }
        } catch (e: Exception) { -1 }
    }
}
