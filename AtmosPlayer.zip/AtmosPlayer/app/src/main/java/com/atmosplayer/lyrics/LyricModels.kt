package com.atmosplayer.lyrics

import androidx.compose.runtime.Immutable

enum class LyricSource { EMBEDDED, TTML_FILE, LRC_FILE, MANUAL, NONE }

@Immutable
data class LyricWord(
    val text: String,
    val startMs: Long,
    val endMs: Long
)

@Immutable
data class LyricLine(
    val startMs: Long,
    val endMs: Long,
    val words: List<LyricWord> = emptyList(),   // 空 = 逐行歌词
    val translation: String? = null,
    val romanization: String? = null,           // 罗马音/拼音（可选，TTML 扩展位）
    val agent: String? = null
) {
    val text: String get() = words.joinToString("") { it.text }
    /** 该行是否有逐词时间（>1 个词才算真正的逐字行） */
    val isWordTimed: Boolean get() = words.size > 1
}

@Immutable
data class Lyrics(
    val lines: List<LyricLine>,
    val source: LyricSource,
    val isWordTimed: Boolean
) {
    fun lineIndexAt(positionMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].startMs <= positionMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }
}
