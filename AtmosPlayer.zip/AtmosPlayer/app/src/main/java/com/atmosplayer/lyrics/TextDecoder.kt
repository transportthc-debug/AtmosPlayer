package com.atmosplayer.lyrics

import org.mozilla.universalchardet.UniversalDetector
import java.io.File
import java.nio.charset.Charset

/**
 * 文本编码识别与解码（解决 .lrc/.ttml 乱码）。
 * juniversalchardet（Mozilla universalchardet 的 Java 移植）可识别
 * UTF-8 / UTF-16 / GB18030 / BIG5 / Shift_JIS 等。
 * 双保险：探测器失败时按 UTF-8 → GB18030 回退，用是否出现替换符判断对错。
 */
object TextDecoder {

    private const val REPLACEMENT = '\uFFFD'

    /** 同 decode，但额外返回实际使用的编码名（供调试日志） */
    fun decodeWithInfo(bytes: ByteArray): Pair<String, String> {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte())
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8) to "UTF-8(BOM)"
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return String(bytes, 2, bytes.size - 2, Charset.forName("UTF-16LE")) to "UTF-16LE(BOM)"
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return String(bytes, 2, bytes.size - 2, Charset.forName("UTF-16BE")) to "UTF-16BE(BOM)"
        if (bytes.all { (it.toInt() and 0xFF) < 0x80 }) return String(bytes, Charsets.UTF_8) to "UTF-8(ascii)"

        val detected = runCatching {
            val d = UniversalDetector(null)
            d.handleData(bytes, 0, bytes.size)
            d.dataEnd()
            d.detectedCharset
        }.getOrNull()
        if (!detected.isNullOrBlank()) {
            val st = runCatching { String(bytes, Charset.forName(detected)) }.getOrNull()
            if (st != null && !st.contains(REPLACEMENT)) return st to detected
        }
        val utf8 = String(bytes, Charsets.UTF_8)
        if (!utf8.contains(REPLACEMENT)) return utf8 to "UTF-8(fallback)"
        val gbk = runCatching { String(bytes, Charset.forName("GB18030")) }.getOrNull()
        if (gbk != null && !gbk.contains(REPLACEMENT)) return gbk to "GB18030(fallback)"
        return utf8 to "UTF-8(forced)"
    }

    fun decode(bytes: ByteArray): String {
        // 1. BOM 优先
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte())
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return String(bytes, 2, bytes.size - 2, Charset.forName("UTF-16LE"))
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return String(bytes, 2, bytes.size - 2, Charset.forName("UTF-16BE"))

        // 2. 纯 ASCII 直接 UTF-8
        if (bytes.all { (it.toInt() and 0xFF) < 0x80 }) return String(bytes, Charsets.UTF_8)

        // 3. juniversalchardet 流式探测
        val detected = runCatching {
            val d = UniversalDetector(null)
            d.handleData(bytes, 0, bytes.size)
            d.dataEnd()
            d.detectedCharset
        }.getOrNull()
        if (!detected.isNullOrBlank()) {
            val s = runCatching { String(bytes, Charset.forName(detected)) }.getOrNull()
            if (s != null && !s.contains(REPLACEMENT)) return s
        }

        // 4. 回退链：UTF-8（严格验证）→ GB18030
        val utf8 = String(bytes, Charsets.UTF_8)
        if (!utf8.contains(REPLACEMENT)) return utf8
        val gbk = runCatching { String(bytes, Charset.forName("GB18030")) }.getOrNull()
        if (gbk != null && !gbk.contains(REPLACEMENT)) return gbk
        return utf8
    }

    fun readFile(file: File): String? =
        runCatching { decode(file.readBytes()) }.getOrNull()
}
