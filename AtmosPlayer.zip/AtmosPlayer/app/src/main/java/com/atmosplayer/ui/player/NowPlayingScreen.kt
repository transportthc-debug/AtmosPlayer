package com.atmosplayer.ui.player

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import com.atmosplayer.artwork.AnimatedArtwork
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.playback.PlayerManager
import com.atmosplayer.ui.components.glassSurface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Apple Music 风格全屏播放页：
 * 背景 = 封面放大模糊 + Palette 取色渐变光晕
 * Pager = 封面页 / 歌词页
 * 底部 = 进度 + 控制 + 队列/信息弹层
 */
@OptIn(ExperimentalFoundationApi::class)
@UnstableApi
@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onClose: () -> Unit
) {
    val state by vm.player.collectAsState()
    val track by vm.currentTrack.collectAsState()
    val lyrics by vm.lyrics.collectAsState()
    val offset by vm.lyricOffset.collectAsState()
    val showTranslation by vm.showTranslation.collectAsState()
    val animatedEnabled by vm.animatedArtworkEnabled.collectAsState()

    // ---- 沉浸封面模式：会话内切换 + 可持久化为默认模式（参考 Apple Music 全屏封面） ----
    val immersiveDefault by vm.immersiveCoverDefault.collectAsState()
    var immersiveOverride by remember { mutableStateOf<Boolean?>(null) }
    val immersiveOn = immersiveOverride ?: immersiveDefault
    val pagerState = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    // 封面取色
    var paletteColors by remember(state.currentTrackId) { mutableStateOf(listOf<Color>()) }
    LaunchedEffect(track?.path) {
        paletteColors = extractPalette(track?.path)
    }

    var showQueue by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0B10))) {
        // ---- 背景层 ----
        if (immersiveOn) {
            // 沉浸模式：封面清晰铺满全屏（Crop），上下渐变压暗保证控件可读
            com.atmosplayer.ui.components.Artwork(
                artworkKey = state.artworkKey,
                original = true,
                shape = androidx.compose.ui.graphics.RectangleShape,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                tag = "immersive"
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.45f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.35f),
                                Color.Black.copy(alpha = 0.82f)
                            )
                        )
                    )
            )
        } else {
            // 经典模式：模糊封面背景
            AsyncImage(
                model = state.artworkKey,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .blur(90.dp)
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            )
        }
        if (paletteColors.isNotEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(paletteColors[0].copy(alpha = 0.35f), Color.Transparent),
                            radius = 1600f
                        )
                    )
            )
        }

        // ---- 主内容 ----
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // 顶栏
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null, tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                // 格式徽章：Dolby Atmos / Dolby Audio / Hi-Res / Lossless
                com.atmosplayer.ui.components.QualityBadgeRow(
                    com.atmosplayer.ui.components.QualityBadges.kinds(
                        state.audioInfo.mime.takeIf { it != "-" } ?: track?.codecMime,
                        track?.path,
                        state.audioInfo.sampleRate.takeIf { it > 0 } ?: track?.sampleRate ?: 0
                    )
                )
                // 沉浸封面模式切换：点按切换会话内模式，长按把当前模式设为默认
                var immersiveMenu by remember { mutableStateOf(false) }
                Box {
                    Icon(
                        if (immersiveOn) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                        contentDescription = "沉浸封面模式",
                        tint = Color.White,
                        modifier = Modifier
                            .combinedClickable(
                                onClick = { immersiveOverride = !immersiveOn },
                                onLongClick = { immersiveMenu = true }
                            )
                            .padding(12.dp)
                    )
                    DropdownMenu(expanded = immersiveMenu, onDismissRequest = { immersiveMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (immersiveOn) "默认使用沉浸模式" else "默认使用经典模式") },
                            onClick = {
                                vm.setImmersiveCoverDefault(immersiveOn)
                                Toast.makeText(ctx, "已保存为默认播放页模式", Toast.LENGTH_SHORT).show()
                                immersiveMenu = false
                            }
                        )
                    }
                }
                IconButton(onClick = { showMore = true }) {
                    Icon(Icons.Rounded.MoreHoriz, null, tint = Color.White)
                }
            }

            if (!immersiveOn) {
                // 经典模式：封面 ⇄ 歌词 滑动切换
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) { page ->
                    when (page) {
                        0 -> ArtworkPage(state, track, animatedEnabled)
                        1 -> LyricsView(
                            lyrics = lyrics,
                            positionMs = state.positionMs,
                            isPlaying = state.isPlaying,
                            offsetMs = offset,
                            showTranslation = showTranslation,
                            onSeek = { vm.seekToLine(it) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // 标题信息
                Column(Modifier.padding(horizontal = 24.dp)) {
                    Text(state.title, color = Color.White, fontSize = 20.sp,
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${state.artist} · ${state.album}",
                        color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                // 沉浸模式：封面铺满，控件全部下压到玻璃面板
                Spacer(Modifier.weight(1f))
            }

            // ---- 液态玻璃控制面板：进度 + 控制 + 功能行整体悬浮 ----
            Column(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .glassSurface(shape = RoundedCornerShape(28.dp),
                        tint = Color.White.copy(alpha = 0.10f), borderAlpha = 0.38f)
                    .padding(vertical = 6.dp)
            ) {
            // 沉浸模式：标题收进玻璃面板顶部
            if (immersiveOn) {
                Column(Modifier.padding(horizontal = 24.dp).padding(top = 10.dp)) {
                    Text(state.title, color = Color.White, fontSize = 20.sp,
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${state.artist} · ${state.album}",
                        color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            // 进度条
            Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                var dragging by remember { mutableStateOf<Float?>(null) }
                val progress = dragging ?: if (state.durationMs > 0)
                    state.positionMs.toFloat() / state.durationMs else 0f
                Slider(
                    value = progress.coerceIn(0f, 1f),
                    onValueChange = { dragging = it },
                    onValueChangeFinished = {
                        dragging?.let { vm.playerManager.seekTo((it * state.durationMs).toLong()) }
                        dragging = null
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                    )
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmtTime(state.positionMs), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                    Text(fmtTime(state.durationMs), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                }
            }

            // 控制条
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.playerManager.toggleShuffle() }) {
                    Icon(Icons.Rounded.Shuffle, null,
                        tint = if (state.shuffle) MaterialTheme.colorScheme.primary
                               else Color.White.copy(alpha = 0.7f))
                }
                IconButton(onClick = { vm.playerManager.prev() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White,
                        modifier = Modifier.size(40.dp))
                }
                IconButton(
                    onClick = { vm.playerManager.togglePlay() },
                    modifier = Modifier
                        .size(72.dp)
                        .glassSurface(shape = RoundedCornerShape(36.dp),
                            tint = Color.White.copy(alpha = 0.16f))
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null, tint = Color.White, modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = { vm.playerManager.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, null, tint = Color.White,
                        modifier = Modifier.size(40.dp))
                }
                IconButton(onClick = { vm.playerManager.cycleRepeat() }) {
                    Icon(
                        when (state.repeatMode) {
                            Player.REPEAT_MODE_ONE -> Icons.Rounded.RepeatOne
                            else -> Icons.Rounded.Repeat
                        },
                        null,
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF)
                            MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            // 底部功能行
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (immersiveOn) {
                    // 沉浸模式歌词入口：退出沉浸并滑到歌词页
                    TextButton(onClick = {
                        immersiveOverride = false
                        scope.launch { pagerState.animateScrollToPage(1) }
                    }) {
                        Icon(Icons.Rounded.Lyrics, null, tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("歌词", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                    }
                }
                TextButton(onClick = { showInfo = true }) {
                    Icon(Icons.Rounded.Info, null, tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("音频信息", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                }
                TextButton(onClick = { showQueue = true }) {
                    Icon(Icons.Rounded.QueueMusic, null, tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("播放队列", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                }
            }
            } // 玻璃控制面板 end
        }
    }

    if (showQueue) {
        QueueSheet(state = state, onDismiss = { showQueue = false },
            onJump = { vm.playerManager.seekToIndex(it); showQueue = false },
            onRemove = { vm.playerManager.removeQueueItem(it) })
    }
    if (showInfo) {
        FormatInfoSheet(info = state.audioInfo, track = track, onDismiss = { showInfo = false })
    }
    if (showMore) {
        MoreSheet(
            track = track,
            offsetMs = offset,
            onOffset = { vm.adjustOffset(it) },
            onDismiss = { showMore = false }
        )
    }
}

@Composable
private fun ArtworkPage(
    state: PlayerManager.UiState,
    track: TrackEntity?,
    animatedEnabled: Boolean
) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val video = if (animatedEnabled) track?.animatedArtworkPath else null
        if (video != null) {
            AnimatedArtwork(
                videoPath = video, visible = true,
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
            )
        } else {
            // 播放页封面：Size.ORIGINAL 高清原图，不压缩
            com.atmosplayer.ui.components.Artwork(
                artworkKey = state.artworkKey,
                original = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .aspectRatio(1f),
                tag = "nowplaying"
            )
        }
    }
}

@Composable
fun AtmosBadge() {
    Box(
        Modifier
            .glassSurface(shape = RoundedCornerShape(8.dp), tint = Color(0xFFD0BCFF).copy(alpha = 0.22f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("DOLBY ATMOS", color = Color(0xFFE6DEFF), fontSize = 10.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun DolbyBadge() {
    Box(
        Modifier
            .glassSurface(shape = RoundedCornerShape(8.dp), tint = Color.White.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("DOLBY", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

private suspend fun extractPalette(path: String?): List<Color> = withContext(Dispatchers.IO) {
    if (path == null) return@withContext emptyList()
    try {
        val bytes = com.atmosplayer.artwork.ArtworkBytes.load(path)?.first ?: return@withContext emptyList()
        // 取色只需小图：采样到 ~128px，避免大图 OOM
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 128) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return@withContext emptyList()
        val p = Palette.from(bmp).generate()
        listOfNotNull(
            p.vibrantSwatch?.rgb?.let(::Color),
            p.mutedSwatch?.rgb?.let(::Color),
            p.darkVibrantSwatch?.rgb?.let(::Color)
        )
    } catch (e: Exception) { emptyList() }
}

fun fmtTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
