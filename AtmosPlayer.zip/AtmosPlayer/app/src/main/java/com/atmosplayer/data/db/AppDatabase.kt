package com.atmosplayer.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        TrackEntity::class, PlaylistEntity::class, PlaylistEntry::class,
        PlaybackStateEntity::class, LyricOffsetEntity::class, LyricsCacheEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun playbackStateDao(): PlaybackStateDao
    abstract fun lyricsDao(): LyricsDao
}
