package com.atmosplayer.playback

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * 播放服务：MediaSessionService + ExoPlayer。
 * 杜比策略：优先选择 AC-4 / EAC3-JOC 音轨，交给系统杜比解码器（PHY110: c2.dolby.*）。
 * 注意：Atmos 渲染由 ColorOS DAP 音效链路完成，App 不绕过系统混音。
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        com.atmosplayer.util.Trace.log("Service.onCreate.begin")
        val player = try {
            buildPlayer(preferDolby = true)
        } catch (e: Throwable) {
            // 杜比优先参数在个别设备上可能触发框架异常 → 退回默认播放器，保证服务可用
            com.atmosplayer.util.Trace.error("buildPlayer(dolby)", e)
            try { buildPlayer(preferDolby = false) } catch (e2: Throwable) {
                com.atmosplayer.util.Trace.error("buildPlayer(default)", e2)
                throw e2
            }
        }
        try {
            mediaSession = MediaSession.Builder(this, player).build()
            com.atmosplayer.util.Trace.log("Service.onCreate.ok")
        } catch (e: Throwable) {
            com.atmosplayer.util.Trace.error("MediaSession.build", e)
            throw e
        }
    }

    private fun buildPlayer(preferDolby: Boolean): ExoPlayer {
        com.atmosplayer.util.Trace.log("buildPlayer preferDolby=$preferDolby")
        val builder = ExoPlayer.Builder(this)
        if (preferDolby) {
            val trackSelector = DefaultTrackSelector(this).apply {
                setParameters(buildUponParameters()
                    .setPreferredAudioMimeTypes(
                        "audio/ac4", "audio/eac3-joc", "audio/eac3",
                        "audio/ac3", "audio/mp4a-latm"
                    )
                )
            }
            builder.setTrackSelector(trackSelector)
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        return builder
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}
