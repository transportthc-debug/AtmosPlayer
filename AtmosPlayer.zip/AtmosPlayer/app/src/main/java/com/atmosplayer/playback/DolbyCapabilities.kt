package com.atmosplayer.playback

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodecList
import android.os.Build

/**
 * 探测设备杜比能力。所有结论来自系统 API，不猜测。
 * 双通道检测（参考 Android 官方 audio-capabilities 文档 + media3 AudioCapabilities 实现）：
 * 1. MediaCodecList —— 解码支持（能否解码该码流）
 * 2. AudioTrack.isDirectPlaybackSupported —— 直通支持（能否不经软解直接输出到音频链路）
 * 两者是不同能力层级，分开报告，互不替代。
 */
object DolbyCapabilities {

    data class Report(
        val ac4Decoders: List<String>,
        val eac3Decoders: List<String>,
        val eac3JocDecoders: List<String>,
        val ac3Decoders: List<String>,
        val dolbyNamedDecoders: List<String>,
        // 直通（direct playback / passthrough）检测
        val directAc3: Boolean = false,
        val directEac3: Boolean = false,
        val directEac3Joc: Boolean = false,
        val directAc4: Boolean = false
    ) {
        val supportsAc4 get() = ac4Decoders.isNotEmpty()
        val supportsAtmosJoc get() = eac3JocDecoders.isNotEmpty()
        val supportsAnyDolby get() = dolbyNamedDecoders.isNotEmpty()
        /** 系统级杜比渲染推断：存在杜比命名的系统解码器（如 c2.dolby.*） */
        val systemDolbyRendering get() = dolbyNamedDecoders.isNotEmpty()
    }

    fun detect(): Report {
        val ac4 = mutableListOf<String>()
        val eac3 = mutableListOf<String>()
        val joc = mutableListOf<String>()
        val ac3 = mutableListOf<String>()
        val dolbyNamed = mutableListOf<String>()
        val list = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
        for (info in list) {
            if (info.isEncoder) continue
            if (info.name.contains("dolby", true)) dolbyNamed += info.name
            for (type in info.supportedTypes) {
                when (type.lowercase()) {
                    "audio/ac4" -> ac4 += info.name
                    "audio/eac3" -> eac3 += info.name
                    "audio/eac3-joc" -> joc += info.name
                    "audio/ac3" -> ac3 += info.name
                }
            }
        }
        return Report(
            ac4, eac3, joc, ac3, dolbyNamed.distinct(),
            directAc3 = directSupported(AudioFormat.ENCODING_AC3),
            directEac3 = directSupported(AudioFormat.ENCODING_E_AC3),
            directEac3Joc = directSupported(AudioFormat.ENCODING_E_AC3_JOC),
            directAc4 = directSupported(ENCODING_AC4)
        )
    }

    /** AudioFormat.ENCODING_AC4 自 API 29 引入；低版本安全降级为"不支持直通" */
    private val ENCODING_AC4: Int
        get() = if (Build.VERSION.SDK_INT >= 29) AudioFormat.ENCODING_AC4 else -1

    /** AudioTrack.isDirectPlaybackSupported：USAGE_MEDIA + 48kHz 立体声基准探测 */
    private fun directSupported(encoding: Int): Boolean {
        if (encoding < 0 || Build.VERSION.SDK_INT < 29) return false
        return runCatching {
            AudioTrack.isDirectPlaybackSupported(
                AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(48000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
        }.getOrDefault(false)
    }

    /** 一行汇总日志（写 trace.txt） */
    fun logReport(r: Report) {
        com.atmosplayer.util.Trace.log(
            "dolby.detect: ac4=${r.ac4Decoders} eac3=${r.eac3Decoders} joc=${r.eac3JocDecoders} " +
            "ac3=${r.ac3Decoders} dolbyNamed=${r.dolbyNamedDecoders} " +
            "direct[ac3=${r.directAc3} eac3=${r.directEac3} joc=${r.directEac3Joc} ac4=${r.directAc4}]"
        )
    }

    /** 查询某 MIME 实际将由哪个解码器处理（如 c2.dolby.ac4.decoder） */
    fun decoderNameFor(mime: String?): String? {
        if (mime.isNullOrBlank() || mime == "-") return null
        return runCatching {
            val format = android.media.MediaFormat().apply {
                setString(android.media.MediaFormat.KEY_MIME, mime)
            }
            MediaCodecList(MediaCodecList.ALL_CODECS).findDecoderForFormat(format)
        }.getOrNull()
    }

    /** 判断一个 mime 是否代表杜比全景声内容 */
    fun isAtmosMime(mime: String?): Boolean =
        mime == "audio/eac3-joc" || mime == "audio/ac4" ||
        mime.equals("audio/x-eac3-joc", true)

    fun isDolbyMime(mime: String?): Boolean =
        isAtmosMime(mime) || mime == "audio/eac3" || mime == "audio/ac3"
}
