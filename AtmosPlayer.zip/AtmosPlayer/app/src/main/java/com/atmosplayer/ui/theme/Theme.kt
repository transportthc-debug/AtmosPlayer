package com.atmosplayer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFD0BCFF),
    onPrimary = Color(0xFF381E72),
    background = Color(0xFF0B0B10),
    surface = Color(0xFF12121A),
    onBackground = Color(0xFFF2F0F7),
    onSurface = Color(0xFFF2F0F7),
    surfaceVariant = Color(0xFF1E1E2A),
    onSurfaceVariant = Color(0xFFCAC4D0)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6750A4),
    background = Color(0xFFF7F5FA),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun AtmosTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        content = content
    )
}
