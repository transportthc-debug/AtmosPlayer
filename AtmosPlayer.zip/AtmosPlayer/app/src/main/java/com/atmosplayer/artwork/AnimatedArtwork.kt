package com.atmosplayer.artwork

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/**
 * 动态封面：同名 .art.mp4 / .mp4 视频静音循环播放（Apple Music 动态封面风格）。
 * 独立于主播放器，用单独的轻量 ExoPlayer 实例；组件销毁时立即释放。
 */
@androidx.media3.common.util.UnstableApi
@Composable
fun AnimatedArtwork(
    videoPath: String,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val player = remember(videoPath) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(java.io.File(videoPath))))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = 0f
            prepare()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    androidx.compose.runtime.LaunchedEffect(visible) {
        if (visible) player.play() else player.pause()
    }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                this.player = player
            }
        }
    )
}
