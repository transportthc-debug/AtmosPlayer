package com.atmosplayer.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.playback.FormatInspector
import com.atmosplayer.playback.PlayerManager
import com.atmosplayer.playback.TrackDetailLoader

/** 播放队列弹层 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    state: PlayerManager.UiState,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit,
    onRemove: (Int) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text("播放队列（${state.queueTitles.size}）",
            fontWeight = FontWeight.Bold, fontSize = 18.sp,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        LazyColumn {
            items(state.queueTitles.size) { i ->
                val (id, title) = state.queueTitles[i]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onJump(i) }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        title,
                        modifier = Modifier.weight(1f),
                        fontWeight = if (id == state.currentTrackId) FontWeight.Bold else FontWeight.Normal,
                        color = if (id == state.currentTrackId) MaterialTheme.colorScheme.primary
                                else androidx.compose.ui.graphics.Color.Unspecified
                    )
                    IconButton(onClick = { onRemove(i) }) {
                        Icon(Icons.Rounded.Close, null, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** 音频信息面板：MediaInfo 风格分组专业参数面板，全部字段优雅降级 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormatInfoSheet(
    info: FormatInspector.AudioInfo,
    track: TrackEntity?,
    onDismiss: () -> Unit
) {
    val path = track?.path
    var details by remember(path) {
        mutableStateOf<TrackDetailLoader.Details?>(null)
    }
    LaunchedEffect(path) {
        if (path != null) details = TrackDetailLoader.load(path, info)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // 头部：文件名 + 格式徽章
            Text("音频信息", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            val d0 = details
            val badgeKinds = com.atmosplayer.ui.components.QualityBadges.kinds(
                d0?.mime ?: track?.codecMime, d0?.filePath ?: track?.path,
                d0?.sampleRate ?: track?.sampleRate ?: 0, d0?.bitDepth ?: 0
            )
            com.atmosplayer.ui.components.QualityBadgeRow(badgeKinds)
            Spacer(Modifier.height(10.dp))

            val d = details
            // ---- 通用 ----
            InfoSection("通用") {
                InfoRow("文件名", d?.fileName ?: "-")
                InfoRow("文件路径", d?.filePath ?: path ?: "-", small = true)
                InfoRow("容器格式", d?.container ?: "-")
                InfoRow("文件大小", TrackDetailLoader.fmtSize(d?.fileSizeBytes ?: 0))
                InfoRow("总时长", fmtTime(d?.durationMs ?: track?.durationMs ?: 0))
                InfoRow("总码率", TrackDetailLoader.fmtBitrate(d?.overallBitrate ?: 0))
            }
            // ---- 标签 ----
            InfoSection("标签") {
                InfoRow("标题", d?.title ?: track?.title ?: "-")
                InfoRow("艺术家", d?.artist ?: track?.artist ?: "-")
                InfoRow("专辑", d?.album ?: track?.album ?: "-")
                InfoRow("专辑艺术家", d?.albumArtist ?: track?.albumArtist ?: "-")
                InfoRow("流派", d?.genre ?: track?.genre ?: "-")
                InfoRow("年份", d?.year ?: "-")
                InfoRow("版权", d?.copyright ?: "-", small = true)
                InfoRow("编码日期", d?.encodedDate ?: "-")
                InfoRow("标签类型", d?.tagType ?: "-")
            }
            // ---- 音频流 ----
            InfoSection("音频流") {
                InfoRow("编码格式", d?.codec ?: info.codec)
                InfoRow("Codec ID", d?.codecId ?: "-")
                InfoRow("MIME", d?.mime ?: info.mime)
                InfoRow("码率", TrackDetailLoader.fmtBitrate(
                    (d?.bitrate ?: 0).takeIf { it > 0 } ?: info.bitrate))
                InfoRow("码率模式", d?.bitrateMode ?: "-")
                InfoRow("采样率", (d?.sampleRate ?: info.sampleRate).takeIf { it > 0 }
                    ?.let { "%,d Hz".format(it) } ?: "-")
                InfoRow("声道数", (d?.channelCount ?: info.channelCount).takeIf { it > 0 }
                    ?.let { "$it ch" } ?: "-")
                InfoRow("声道布局", d?.channelLayout ?: info.channelLayout)
                InfoRow("位深", (d?.bitDepth ?: 0).takeIf { it > 0 }?.let { "$it bit" } ?: "-")
                InfoRow("压缩模式", d?.compressionMode ?: "-")
                InfoRow("流大小", TrackDetailLoader.fmtSize(d?.streamSizeBytes ?: 0))
                InfoRow("采样总数", (d?.samplingCount ?: 0).takeIf { it > 0 }
                    ?.let { "%,d".format(it) } ?: "-")
                InfoRow("解码器", d?.decoderName ?: "-", small = true)
                InfoRow("杜比全景声", if (d?.isDolbyAtmos ?: info.isDolbyAtmos)
                    "是（Atmos / Immersive）" else if (d?.isDolby == true || info.isDolby)
                    "杜比音频（非 Atmos）" else "否")
                InfoRow("Hi-Res", if (d?.isHiRes == true) "是（高解析无损）" else "否")
            }
            // ---- 其他 ----
            InfoSection("其他") {
                InfoRow("封面来源", d?.artworkSource ?: "-")
                InfoRow("歌词来源", lyricsSourceText(track), small = true)
                InfoRow("音轨 ID", track?.id?.take(12) ?: "-", small = true)
                InfoRow("音轨数量", (d?.trackCount ?: 0).takeIf { it > 0 }?.toString() ?: "-")
                InfoRow("编码器 / 编码库", d?.encoder ?: "-", small = true)
            }
        }
    }
}

private fun lyricsSourceText(track: TrackEntity?): String {
    if (track == null) return "-"
    val parts = mutableListOf<String>()
    if (track.hasEmbeddedLyrics) parts += "内嵌歌词"
    val f = java.io.File(track.path)
    if (java.io.File(f.parentFile, f.nameWithoutExtension + ".lrc").exists()) parts += "同名 .lrc"
    if (java.io.File(f.parentFile, f.nameWithoutExtension + ".ttml").exists()) parts += "同名 .ttml"
    return if (parts.isEmpty()) "无歌词" else parts.joinToString(" + ")
}

@Composable
private fun InfoSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Spacer(Modifier.height(14.dp))
    Text(
        title, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary, letterSpacing = 2.sp
    )
    HorizontalDivider(Modifier.padding(vertical = 6.dp), thickness = 0.5.dp,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
    Column(content = content)
}

@Composable
private fun InfoRow(label: String, value: String, small: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, modifier = Modifier.width(96.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, fontSize = if (small) 11.sp else 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** 更多操作弹层：歌词偏移等 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreSheet(
    track: TrackEntity?,
    offsetMs: Long,
    onOffset: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 40.dp)) {
            Text(track?.title ?: "更多操作", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(16.dp))
            Text("歌词偏移：${if (offsetMs >= 0) "+" else ""}${offsetMs} ms", fontSize = 14.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onOffset(-500) }) { Text("-0.5s") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { onOffset(-100) }) { Text("-0.1s") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { onOffset(100) }) { Text("+0.1s") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { onOffset(500) }) { Text("+0.5s") }
            }
        }
    }
}
