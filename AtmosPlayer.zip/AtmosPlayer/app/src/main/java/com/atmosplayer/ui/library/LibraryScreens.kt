package com.atmosplayer.ui.library

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.atmosplayer.data.db.TrackEntity
import com.atmosplayer.playback.PlayerManager
import com.atmosplayer.ui.components.glassSurface

enum class LibraryTab(val label: String) {
    SONGS("歌曲"), ALBUMS("专辑"), ARTISTS("艺术家"), FOLDERS("文件夹"), ATMOS("全景声")
}

/** 曲库主页：Tab + 列表 + 搜索 */
@UnstableApi
@Composable
fun LibraryScreen(vm: LibraryViewModel, playerState: PlayerManager.UiState) {
    val tracks by vm.tracks.collectAsState()
    val atmos by vm.atmos.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val scanCount by vm.scanCount.collectAsState()
    val query by vm.query.collectAsState()
    val searchResults by vm.searchResults.collectAsState()

    var tab by remember { mutableStateOf(LibraryTab.SONGS) }
    var grouping by remember { mutableStateOf<Pair<String, LibraryTab>?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("AtmosPlayer", fontSize = 26.sp, fontWeight = FontWeight.Bold,
                color = Color.White)
            Spacer(Modifier.weight(1f))
            if (scanning) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                TextButton(onClick = { vm.scan() }) {
                    Icon(Icons.Rounded.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("扫描", color = Color.White)
                }
            }
        }
        if (scanCount >= 0 && !scanning) {
            Text("已索引 $scanCount 首 · 杜比全景声 ${atmos.size} 首",
                color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 20.dp))
        }

        OutlinedTextField(
            value = query,
            onValueChange = { vm.setQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("搜索歌曲 / 艺术家 / 专辑") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(24.dp)
        )

        if (query.isBlank()) {
            ScrollableTabRow(
                selectedTabIndex = tab.ordinal,
                edgePadding = 12.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                LibraryTab.entries.forEach { t ->
                    Tab(
                        selected = tab == t,
                        onClick = { tab = t; grouping = null },
                        text = { Text(t.label) }
                    )
                }
            }
            val group = grouping
            if (group != null) {
                GroupTrackList(vm, group.first, group.second, playerState,
                    onBack = { grouping = null })
            } else when (tab) {
                LibraryTab.SONGS -> TrackList(tracks, playerState,
                    onClick = { i -> vm.play(tracks, i) },
                    onFav = { vm.toggleFavorite(it) })
                LibraryTab.ATMOS -> TrackList(atmos, playerState,
                    onClick = { i -> vm.play(atmos, i) },
                    onFav = { vm.toggleFavorite(it) })
                LibraryTab.ALBUMS -> GroupList(tracks.groupBy { it.album }, "张专辑",
                    onOpen = { grouping = it to LibraryTab.ALBUMS })
                LibraryTab.ARTISTS -> GroupList(tracks.groupBy { it.artist }, "位艺术家",
                    onOpen = { grouping = it to LibraryTab.ARTISTS })
                LibraryTab.FOLDERS -> {
                    var folderActionTarget by remember { mutableStateOf<String?>(null) }
                    GroupList(
                        tracks.groupBy { it.folder }, "个文件夹",
                        onOpen = { grouping = it to LibraryTab.FOLDERS },
                        onLongPress = { folderActionTarget = it }
                    )
                    folderActionTarget?.let { folder ->
                        FolderActionDialog(
                            folder = folder,
                            onDismiss = { folderActionTarget = null },
                            onBlock = { vm.blockFolder(folder) },
                            onScanOnly = { vm.scanOnlyThisFolder(folder) },
                            onAddWhitelist = { vm.addWhitelist(folder) },
                            onRemove = { vm.removeFolderFromLibrary(folder) }
                        )
                    }
                }
            }
        } else {
            TrackList(searchResults, playerState,
                onClick = { i -> vm.play(searchResults, i) },
                onFav = { vm.toggleFavorite(it) })
        }
    }
}

@Composable
private fun GroupTrackList(
    vm: LibraryViewModel,
    key: String,
    tab: LibraryTab,
    playerState: PlayerManager.UiState,
    onBack: () -> Unit
) {
    val tracks by vm.tracks.collectAsState()
    val list = remember(key, tab, tracks) {
        when (tab) {
            LibraryTab.ALBUMS -> tracks.filter { it.album == key }
            LibraryTab.ARTISTS -> tracks.filter { it.artist == key }
            else -> tracks.filter { it.folder == key }
        }
    }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Color.White) }
            Text(key, color = Color.White, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        TrackList(list, playerState, onClick = { vm.play(list, it) }, onFav = { vm.toggleFavorite(it) })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GroupList(
    groups: Map<String, List<TrackEntity>>,
    unit: String,
    onOpen: (String) -> Unit,
    onLongPress: ((String) -> Unit)? = null
) {
    LazyColumn(Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 170.dp)) {  // 底部让位给悬浮玻璃底栏
        item {
            Text("${groups.size} $unit", color = Color.White.copy(alpha = 0.4f),
                fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
        }
        items(groups.entries.toList().sortedBy { it.key }.size) { idx ->
            val (name, list) = groups.entries.toList().sortedBy { it.key }[idx]
            Row(
                Modifier
                    .fillMaxWidth()
                    .combinedClickable(
                        onClick = { onOpen(name) },
                        onLongClick = { onLongPress?.invoke(name) }
                    )
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .glassSurface(shape = RoundedCornerShape(10.dp),
                            tint = Color.White.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Album, null, tint = Color.White.copy(alpha = 0.7f))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = Color.White, fontSize = 16.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${list.size} 首" + if (list.any { it.isDolbyAtmos }) " · 含全景声" else "",
                        color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun TrackList(
    tracks: List<TrackEntity>,
    playerState: PlayerManager.UiState,
    onClick: (Int) -> Unit,
    onFav: (TrackEntity) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 170.dp)) {  // 底部让位给悬浮玻璃底栏
        items(tracks.size, key = { tracks[it].id }) { i ->
            val t = tracks[i]
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onClick(i) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                com.atmosplayer.ui.components.Artwork(
                    artworkKey = "art://${t.path}",
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(42.dp),
                    tag = "list"
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.title,
                            color = if (t.id == playerState.currentTrackId)
                                MaterialTheme.colorScheme.primary else Color.White,
                            fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        val badges = com.atmosplayer.ui.components.QualityBadges.forTrack(t)
                        if (badges.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            com.atmosplayer.ui.components.QualityBadgeRow(badges, compact = true)
                        }
                    }
                    Text(
                        "${t.artist} · ${t.album}" +
                            (t.codecMime?.let { " · ${it.removePrefix("audio/").uppercase()}" } ?: ""),
                        color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { onFav(t) }) {
                    Icon(
                        if (t.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        null,
                        tint = if (t.isFavorite) Color(0xFFFF5C8A) else Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/** 文件夹长按动作（参考 OuterTune / Musicolet）：屏蔽 / 只扫此目录 / 加白名单 / 从曲库移除 */
@Composable
private fun FolderActionDialog(
    folder: String,
    onDismiss: () -> Unit,
    onBlock: () -> Unit,
    onScanOnly: () -> Unit,
    onAddWhitelist: () -> Unit,
    onRemove: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(folder.substringAfterLast('/'), fontSize = 17.sp) },
        text = {
            Column {
                Text(folder, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(14.dp))
                FolderActionItem("只扫描此文件夹", "切换为白名单模式，白名单仅此目录") { onScanOnly(); onDismiss() }
                FolderActionItem("添加到白名单", "白名单模式下纳入扫描范围") { onAddWhitelist(); onDismiss() }
                FolderActionItem("屏蔽此文件夹", "加入黑名单并重新扫描") { onBlock(); onDismiss() }
                FolderActionItem("从曲库移除", "仅删除已索引条目，不影响下次扫描") { onRemove(); onDismiss() }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
private fun FolderActionItem(title: String, desc: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp)
    ) {
        Text(title, color = Color.White, fontSize = 15.sp)
        Text(desc, color = Color.White.copy(alpha = 0.45f), fontSize = 12.sp)
    }
}
