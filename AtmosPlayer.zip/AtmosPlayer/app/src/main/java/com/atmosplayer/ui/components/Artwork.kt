package com.atmosplayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import coil.size.Size

/**
 * 统一封面组件：
 * - original = true 时请求 Size.ORIGINAL（播放页高清原图）
 * - 加载中/失败/无封面 → 渐变默认封面 + 音符图标
 */
@Composable
fun Artwork(
    artworkKey: String?,
    modifier: Modifier = Modifier,
    shape: Shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    original: Boolean = false,
    contentScale: ContentScale = ContentScale.Crop,
    tag: String = "artwork"
) {
    val context = LocalContext.current
    // UI 绑定日志：渲染处来源 + 当前 key
    androidx.compose.runtime.LaunchedEffect(artworkKey) {
        com.atmosplayer.util.Trace.log("ui.render[$tag] key=$artworkKey original=$original")
    }
    val request = androidx.compose.runtime.remember(artworkKey, original) {
        ImageRequest.Builder(context)
            .data(artworkKey)
            .apply { if (original) size(Size.ORIGINAL) }
            .build()
    }
    SubcomposeAsyncImage(
        model = request,
        contentDescription = null,
        contentScale = contentScale,
        modifier = modifier.clip(shape),
        onSuccess = { state ->
            com.atmosplayer.util.Trace.log("ui.load[$tag] SUCCESS key=$artworkKey size=${state.painter.intrinsicSize}")
        },
        onError = { state ->
            com.atmosplayer.util.Trace.log("ui.load[$tag] FAILURE key=$artworkKey reason=${state.result.throwable}")
        },
        loading = { DefaultCover() },
        error = { DefaultCover() }
    )
}

/** 默认封面：紫黑渐变 + 音符 */
@Composable
fun DefaultCover() {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF3D2A6E), Color(0xFF1A1030))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.MusicNote, null,
            tint = Color.White.copy(alpha = 0.5f),
            modifier = Modifier.size(40.dp)
        )
    }
}
